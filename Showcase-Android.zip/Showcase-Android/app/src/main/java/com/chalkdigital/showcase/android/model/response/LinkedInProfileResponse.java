package com.chalkdigital.showcase.android.model.response;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * Created by arungupta on 31/08/16.
 */
public class LinkedInProfileResponse implements Parcelable {

    private String id;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }


    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(this.id);
    }

    public LinkedInProfileResponse() {
    }

    protected LinkedInProfileResponse(Parcel in) {
        this.id = in.readString();
    }

    public static final Parcelable.Creator<LinkedInProfileResponse> CREATOR = new Parcelable.Creator<LinkedInProfileResponse>() {
        @Override
        public LinkedInProfileResponse createFromParcel(Parcel source) {
            return new LinkedInProfileResponse(source);
        }

        @Override
        public LinkedInProfileResponse[] newArray(int size) {
            return new LinkedInProfileResponse[size];
        }
    };
}
