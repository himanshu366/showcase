package com.chalkdigital.showcase.android.model.response;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * Created by arungupta on 31/08/16.
 */
public class LinkedInAccessResponse implements Parcelable {
    private String access_token;

    public String getAccess_token() {
        return access_token;
    }

    public void setAccess_token(String access_token) {
        this.access_token = access_token;
    }


    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(this.access_token);
    }

    public LinkedInAccessResponse() {
    }

    protected LinkedInAccessResponse(Parcel in) {
        this.access_token = in.readString();
    }

    public static final Parcelable.Creator<LinkedInAccessResponse> CREATOR = new Parcelable.Creator<LinkedInAccessResponse>() {
        @Override
        public LinkedInAccessResponse createFromParcel(Parcel source) {
            return new LinkedInAccessResponse(source);
        }

        @Override
        public LinkedInAccessResponse[] newArray(int size) {
            return new LinkedInAccessResponse[size];
        }
    };
}
