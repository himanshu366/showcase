package com.chalkdigital.showcase.android.contants;

/**
 * Created by arungupta on 22/06/16.
 */
public class Keys {
    public final static String KEY_Device_OS                                = "Device-OS";
    public final static String KEY_CONTENT_TYPE                             = "Content-Type";
    public final static String KEY_AUTHORIZATION                            = "Authorization";
    public final static String KEY_APPNAME                                  = "appname";
    public final static String KEY_PORTALNAME                               = "portalName";
    public final static String KEY_FONTNAME                                 = "fontname";
    public final static String KEY_FONTSIZE                                 = "fontsize";
    public final static String KEY_CHARSPACING                              = "charspacing";
    public final static String KEY_LINESPACING                              = "linespacing";
    public final static String KEY_COLOR                                    = "color";
    public final static String KEY_ALIGNMENT                                = "alignment";
    public final static String KEY_SCREENNAME                               = "screenname";
    public final static String KEY_ABOUTFRAGMENTINDEX                       = "aboutFragmentIndex";
    public final static String KEY_DASHBOARDSTATSFRAGMENTINDEX              = "dashboardStatsFragmentIndex";
    public final static String KEY_USERNAME                                 = "username";
    public final static String KEY_ISLAUNCHEDEARLIER                        = "isLaunchedEarlier";
    public final static String KEY_PROVIDER                                 = "provider";
    public final static String KEY_URL                                      = "url";
    public final static String KEY_AGENTINFO                                = "agentInfo";
    public final static String KEY_USERID                                   = "userId";
    public final static String KEY_CREDITBALANCE                            = "creditBalance";
    public final static String KEY_TOKEN                                    = "token";
    public final static String KEY_REFRESHTOKEN                             = "refreshToken";
    public final static String KEY_PASSWORD                                 = "password";
    public final static String KEY_AGENTIMAGEURL                            = "agentImageUrl";
    public final static String KEY_AGENTIMAGEPATH                           = "agentImagePath";
    public final static String KEY_FIRSTNAME                                = "firstName";
    public final static String KEY_LASTNAME                                 = "lastName";
    public final static String KEY_IMAGE                                    = "image";
    public final static String KEY_TEXT                                     = "text";
    public final static String KEY_HINT                                     = "placeholder";
    public final static String KEY_USERIMAGEDATATAG                         = "userImageDataTag";
    public final static String KEY_VIEWS                                    = "views";
    public final static String KEY_300X250                                  = "300x250";
    public final static String KEY_300X50                                   = "300x50";
//    public final static String KEY_LASTNAME                                 = "lastName";

}
