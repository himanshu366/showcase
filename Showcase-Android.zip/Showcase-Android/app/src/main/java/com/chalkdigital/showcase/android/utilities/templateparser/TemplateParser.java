package com.chalkdigital.showcase.android.utilities.templateparser;

import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import androidx.percentlayout.widget.PercentLayoutHelper;
import androidx.percentlayout.widget.PercentRelativeLayout;
import android.view.Gravity;
import android.view.View;
import android.widget.ImageView;

import com.chalkdigital.showcase.android.R;
import com.chalkdigital.showcase.android.contants.Keys;
import com.chalkdigital.showcase.android.listeners.TemplateEventListener;
import com.chalkdigital.showcase.android.model.data.DesignData;
import com.chalkdigital.showcase.android.model.data.UserData;
import com.chalkdigital.showcase.android.utilities.pinchzoom.TouchImageView;
import com.chalkdigital.showcase.android.utilities.util.Util;
import com.chalkdigital.showcase.android.utilities.util.ViewIdGenerator;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

/**
 * Created by arungupta on 03/10/16.
 */

public class TemplateParser {

    private enum CDLayoutAttribute {
        NULL(0),
        MARGIN_LEFT(1),
        MARGIN_RIGHT(2),
        MARGIN_TOP(3),
        MARGIN_BOTTOM(4),
        MARGIN(5),
        HEIGHT(6),
        WIDTH(7);


        private int attribute;
        CDLayoutAttribute(int attribute) {
            this.attribute = attribute;
        }

        public int getCDViewAttribute(){
            return attribute;
        }
    }

    public static final String FONT_NAME            = "fontName";
    public static final String FONT_SIZE            = "fontSize";
    public static final String FONT_CHAR_SPACING    = "fontCharSpacing";
    public static final String FONT_LINE_SPACING    = "fontLineSpacing";
    public static final String TEXT_COLOR           = "textColor";
    public static final String TEXT_ALIGNMENT       = "alignment";
    public static final String RIGHT                = "right";
    public static final String LEFT                 = "left";
    public static final String CENTER               = "center";
    public static final String NORMAL               = "normal";
    public static final String CONTAINERS           = "containers";
    public static final String PLACEHOLDER          = "placeholder";
    public static final String DATATAG              = "dataTag";
    public static final String LARGE_TEMPLATES      = "templates_300X250";
    public static final String SMALL_TEMPLATES      = "templates_300X50";
    public static final String ADD_IMAGE_ENABLED    = "addImageEnabled";

    private static final String MARGIN_TOP          = "marginTop";
    private static final String MARGIN_LEFT         = "marginLeft";
    private static final String MARGIN_RIGHT        = "marginRight";
    private static final String MARGIN_BOTTOM       = "marginBottom";
//  private static final String MARGIN              = "margin";
    private static final String SCALE               = "scale";
    private static final String TEMPLATE_WIDTH      = "width";
    private static final String TEMPLATE_HEIGHT     = "height";
    private static final String HORIZONTAL          = "horizontal";
    private static final String VERTICAL            = "vertical";
    private static final String BOTH                = "both";
    private static final String TYPE                = "type";
    private static final String IMAGE               = "image";
    private static final String TEXTFIELD           = "textField";
    private static final String IMAGE_NAME          = "imageName";
    private static final String BELOW               = "below";
    private static final String ABOVE               = "above";
    private static final String TO_LEFT_OF          = "toLeftOf";
    private static final String TO_RIGHT_OF         = "toRightOf";
    private static final String BACKGROUND_VIEW     = "view";
    private static final String TEMPLATE_BACKGROUND_COLOR   = "backgroundColor";
    private static final String BACKGROUND_ALPHA    = "alpha";

    private static TemplateParser mTemplateParser;
    private Context mContext;

    public static final String MAIN_IMAGE_VIEW_TAG         = "mainImageView";
    public static final String IMAGE_PLACEHOLDER_TAG       = "imagePlaceholder";

    private TemplateParser() {

    }

    public static TemplateParser getInstance(Context context){
        if (mTemplateParser == null)
            mTemplateParser = new TemplateParser();
        mTemplateParser.mContext = context;
        return mTemplateParser;
    }

    public int renderTemplateInView(PercentRelativeLayout mainView, DesignData data, final TemplateEventListener templateEventListener, Map<String, UserData> userDataDict, int offset, boolean animated){
        float containerTemplateHeight = Float.parseFloat(data.getHeight());
        float containerTemplateWidth = Float.parseFloat(data.getWidth());
        HashMap<String, DesignData> containers = data.getContainers();
        if (containers!=null && containers.size()>0){
            offset = renderTemplateInView(mainView, containers, templateEventListener, userDataDict, offset, containerTemplateWidth, containerTemplateHeight);
            data.setContainers(null);
        }
        TouchImageView imageView = (TouchImageView)mainView.findViewWithTag(MAIN_IMAGE_VIEW_TAG);
        ImageView placeholderImageView = (ImageView)mainView.findViewWithTag(IMAGE_PLACEHOLDER_TAG);
        imageView.properties = data;
        String dataTagString = data.getDataTag();
        boolean adImageEnabled = data.getAddImageEnabled();
        if (adImageEnabled){
            imageView.setOnClickListener(templateEventListener);
            imageView.setVisibility(View.VISIBLE);
            if (userDataDict.containsKey(dataTagString)){
                imageView.setImageURI(Uri.parse(userDataDict.get(dataTagString).toString()));
                placeholderImageView.setVisibility(View.GONE);
            }else{
                placeholderImageView.setVisibility(View.VISIBLE);
            }
        }else{
            imageView.setOnClickListener(null);
            imageView.setVisibility(View.INVISIBLE);
            placeholderImageView.setVisibility(View.GONE);
        }
        if (animated){

        }
        return offset;
    }

    private int renderTemplateInView(PercentRelativeLayout mainView, HashMap<String, DesignData> containersDict,
                                     final TemplateEventListener templateEventListener, Map<String, UserData> userDataDict,
                                     int offset, float containerTemplateWidth, float containerTemplateHeight){

        HashMap<String, View> viewsDict = new HashMap<String, View>();
        for (String containerId : containersDict.keySet()){
            DesignData viewData = containersDict.get(containerId);
            View view = null;
            HashMap<String, DesignData> containersData = viewData.getContainers();
            if (containersData!=null && containersData.size()>0){
                viewData.setContainers(null);
            }
            if (viewData.getType().equals(IMAGE)){
                CDTemplateImageButton button = new CDTemplateImageButton(mContext);
                button.setOnClickListener(templateEventListener);
                button.setBackgroundResource(R.color.white);
                GradientDrawable gd = new GradientDrawable();
                gd.setColor(0xFFFFFF); // Changes this drawable to use a single color instead of a gradient
                gd.setStroke(1, 0xEAEAEA);
                button.properties = viewData;
                view = button;
            }else if (viewData.getType().equals(TEXTFIELD)){
                CDTemplateEditText editText = new CDTemplateEditText(mContext);
//                Util.setCursorDrawableColor(editText, Constants.tintColor);
                //editText.addTextChangedListener(templateEventListener);
                editText.setOnFocusChangeListener(templateEventListener);
                editText.setMaxLines(1);
                editText.setPadding(5,0,5,0);
                editText.properties = viewData;
                editText.format();
                if (viewData.getAlignMent()!=null){
                    if (viewData.getAlignMent().equals(RIGHT))
                        editText.setGravity(Gravity.RIGHT);
                    else if (viewData.getAlignMent().equals(LEFT))
                        editText.setGravity(Gravity.LEFT);
                }
                view = editText;
            }else if (viewData.getType().equals(BACKGROUND_VIEW)){
                CDTemplateView templateView = new CDTemplateView(mContext);
                templateView.properties = viewData;
                view = templateView;
            }
            view.setTag(containerId);
//            if (viewData.getBackgroundColor()!=null){
//                int color = Color.WHITE;
//                try {
//                    color = Color.parseColor("#"+viewData.getBackgroundColor());
//                } catch (Exception e) {
//                    e.printStackTrace();
//                }
//                view.setBackgroundColor(color);
//            }
//
//            try {
//                if (viewData.getAlpha()!=null){
//                    view.setAlpha(Float.parseFloat(viewData.getAlpha()));
//                }
//            } catch (NumberFormatException e) {
//                e.printStackTrace();
//            }

            float alpha = 1;
            String alphaString = viewData.getAlpha();
            if (alphaString!=null){
                alpha = Float.parseFloat(alphaString);
                alpha = Math.round(alpha*255);
            }

            if (viewData.getBackgroundColor()!=null && !viewData.getBackgroundColor().equals(""))
                view.setBackgroundColor(Color.parseColor("#"+String.format("%02X",(int)alpha & 0xFF)+viewData.getBackgroundColor()));
            //view.setTag(offset);
            view.setId(ViewIdGenerator.generateViewId());
            view.setVisibility(View.VISIBLE);
            PercentRelativeLayout.LayoutParams params = new PercentRelativeLayout.LayoutParams(PercentRelativeLayout.LayoutParams.MATCH_PARENT, PercentRelativeLayout.LayoutParams.MATCH_PARENT);
            mainView.addView(view, params);
            viewsDict.put(containerId, view);
            String dataTagString = viewData.getDataTag();
            if (dataTagString!=null){
                processSubview(view, dataTagString, userDataDict, viewData);
            }
            offset++;
            if (containersData!=null && containersData.size()>0){
                float subContainerTemplateHeight = Float.parseFloat(viewData.getHeight());
                float subContainerTemplateWidth = Float.parseFloat(viewData.getWidth());
                offset = renderTemplateInView((CDTemplateView)view, containersData, templateEventListener, userDataDict, offset, subContainerTemplateWidth, subContainerTemplateHeight);
            }
        }

        for (String containerId : containersDict.keySet()){
            DesignData subview = containersDict.get(containerId);
            View currentView = viewsDict.get(containerId);
            PercentRelativeLayout.LayoutParams params = (PercentRelativeLayout.LayoutParams)currentView.getLayoutParams();
            float scaleValue = 0;
            if (subview.getScale()!=null && !subview.getScale().equals("")){
                String scaleSting = subview.getScale();
                String[] ratios = scaleSting.split(":");
                scaleValue = Float.parseFloat(ratios[0])/Float.parseFloat(ratios[1]);
            }

            CDLayoutAttribute attribute;
            int relation;
            View relatedTo = null;

            if (subview.getMarginTop()!=null && !subview.getMarginTop().equals("")){
                attribute = CDLayoutAttribute.MARGIN_TOP;
                boolean isBelow = (subview.getBelow()!=null && !subview.getBelow().equals(""));
                float margin = Float.parseFloat(subview.getMarginTop());
                if (isBelow){
                    relatedTo = viewsDict.get(subview.getBelow());
                    relation = PercentRelativeLayout.BELOW;
                }else{
                    relation = PercentRelativeLayout.ALIGN_PARENT_TOP;
                }
                addRuleForView(params, relatedTo, relation, attribute, margin, scaleValue>0, containerTemplateHeight);
            }

            if (subview.getMarginLeft()!=null && !subview.getMarginLeft().equals("")){
                attribute = CDLayoutAttribute.MARGIN_LEFT;
                boolean isBelow = subview.getToRightOf()!=null && !subview.getToRightOf().equals("");
                float margin = Float.parseFloat(subview.getMarginLeft());
                if (isBelow){
                    relatedTo = viewsDict.get(subview.getToRightOf());
                    relation = PercentRelativeLayout.RIGHT_OF;
                }else{
                    relation = PercentRelativeLayout.ALIGN_PARENT_LEFT;
                }
                addRuleForView(params, relatedTo, relation, attribute, margin, scaleValue>0, containerTemplateWidth);
            }

            if (subview.getWidth()!=null && !subview.getWidth().equals("")){
                attribute = CDLayoutAttribute.WIDTH;
                float width = Float.parseFloat(subview.getWidth());
                setAttribute(params, attribute, width, scaleValue>0, containerTemplateWidth);
            }

            if (subview.getHeight()!=null && !subview.getHeight().equals("")){
                attribute = CDLayoutAttribute.HEIGHT;
                float height = Float.parseFloat(subview.getHeight());
                setAttribute(params, attribute, height, scaleValue>0, containerTemplateHeight);
            }

            if (subview.getCenter()!=null && !subview.getCenter().equals("")){
                if (subview.getCenter().equals(BOTH) || subview.getCenter().equals(HORIZONTAL)){
                    centerHorizontally(currentView, params);
                }
                if (subview.getCenter().equals(BOTH) || subview.getCenter().equals(VERTICAL)){
                    centerVertcally(currentView, params);
                }
            }
            currentView.setLayoutParams(params);
        }
        return offset;

    }

    private void processSubview(View view, String dataTagString, Map<String, UserData> userDataDict, DesignData viewDict){
        UserData userData;
        Set<View> set;
        if (!userDataDict.keySet().contains(dataTagString)) {
            userData = new UserData();
            set = new HashSet<View>();
            if (view.getClass() == CDTemplateImageButton.class) {
                CDTemplateImageButton cdTemplateImageButton = (CDTemplateImageButton) view;
                if (dataTagString.equals(Keys.KEY_USERIMAGEDATATAG)) {
                    String agentImagePath = Util.getStringFromSharedPreferences(Keys.KEY_AGENTIMAGEPATH, "", mContext);
                    if (agentImagePath != null && !agentImagePath.equals("")) {
                        userData.setImage(agentImagePath);
                        userData.setTextChanged(false);
                        cdTemplateImageButton.hasData = true;
                        cdTemplateImageButton.setImageURI(Uri.parse(agentImagePath));
                        cdTemplateImageButton.setScaleType(ImageView.ScaleType.CENTER_CROP);
                    }
                }
            } else if (view.getClass() == CDTemplateEditText.class) {
                userData.setText("");
                userData.setTextChanged(false);
                userData.setColorChanged(false);
                CDTemplateEditText cdTemplateEditText = (CDTemplateEditText) view;
                cdTemplateEditText.setHint(viewDict.getPlaceholder());
                if (cdTemplateEditText.properties.getFontName() == null){
                    cdTemplateEditText.properties.setFontName("normal");
                }
            }
        } else {
            userData = userDataDict.get(dataTagString);
            set = userData.getViews();
            if (view.getClass() == CDTemplateImageButton.class) {
                CDTemplateImageButton cdTemplateImageButton = (CDTemplateImageButton) view;
                cdTemplateImageButton.hasData = true;
                if (userData.getImage() != null)
                    cdTemplateImageButton.setImageURI(Uri.parse(userData.getImage()));
                cdTemplateImageButton.setScaleType(ImageView.ScaleType.CENTER_CROP);
            } else if (view.getClass() == CDTemplateEditText.class) {
                CDTemplateEditText cdTemplateEditText = (CDTemplateEditText) view;
                String text = userData.getText();
                if (text != null && !text.equals("")) {
                    cdTemplateEditText.setText(text);
                } else {
                    cdTemplateEditText.setHint(viewDict.getPlaceholder());
                }
                if (cdTemplateEditText.properties.getFontName() == null){
                    cdTemplateEditText.properties.setFontName("normal");
                }
            }

        }
        set.add(view);
        userData.setViews(set);
        userDataDict.put(dataTagString, userData);
    }


     private void addRuleForView(PercentRelativeLayout.LayoutParams params, View relatedTo, int relation, CDLayoutAttribute attribute, float value, boolean inScale, float respectiveParentValue){
         if (relatedTo!=null)
             params.addRule(relation, relatedTo.getId());
         else
             params.addRule(relation);
         setAttribute(params, attribute, value, inScale, respectiveParentValue);
    }

    private void setAttribute(PercentRelativeLayout.LayoutParams params, CDLayoutAttribute attribute, float value, boolean inScale, float respectiveParentValue){
        if (!inScale){
            int roundedValue = Math.round(value);
            switch (attribute){
                case MARGIN_TOP:
                    params.topMargin = roundedValue;
                    break;
                case MARGIN_LEFT:
                    params.leftMargin = roundedValue;
                    break;
                case MARGIN_RIGHT:
                    params.rightMargin = roundedValue;
                    break;
                case MARGIN_BOTTOM:
                    params.bottomMargin = roundedValue;
                    break;
                case MARGIN:
                    params.setMargins(roundedValue, roundedValue, roundedValue, roundedValue);
                    break;
                case HEIGHT:
                    params.height = roundedValue;
                    break;
                case WIDTH:
                    params.width = roundedValue;
                    break;
                default:
                    break;
            }
        }
        else {
            value = value/respectiveParentValue;
            PercentLayoutHelper.PercentLayoutInfo percentLayoutInfo = params.getPercentLayoutInfo();
            switch (attribute){
                case MARGIN_TOP:
                    percentLayoutInfo.topMarginPercent = value;
                    break;
                case MARGIN_LEFT:
                    percentLayoutInfo.leftMarginPercent = value;
                    break;
                case MARGIN_RIGHT:
                    percentLayoutInfo.rightMarginPercent = value;
                    break;
                case MARGIN_BOTTOM:
                    percentLayoutInfo.bottomMarginPercent = value;
                    break;
                case MARGIN:
                    percentLayoutInfo.topMarginPercent = value;
                    percentLayoutInfo.leftMarginPercent = value;
                    percentLayoutInfo.rightMarginPercent = value;
                    percentLayoutInfo.bottomMarginPercent = value;
                    break;
                case HEIGHT:
                    percentLayoutInfo.heightPercent = value;
                    break;
                case WIDTH:
                    percentLayoutInfo.widthPercent = value;
                    break;
                default:
                    break;
            }
        }
    }



    private float getMaxY(String containerId, Map<String, DesignData> containersData) {
        DesignData viewData = containersData.get(containerId);
        float maxY = Float.parseFloat(viewData.getHeight());
        maxY += Float.parseFloat(viewData.getMarginTop());
        if (viewData.getBelow()!=null && !viewData.getBelow().equals("") ) {
            maxY += getMaxX(viewData.getBelow(), containersData);
        }
        return maxY;
    }

    private float getMinY(String containerId, Map<String, DesignData> containersData) {
        DesignData viewData = containersData.get(containerId);
        float minY = Float.parseFloat(viewData.getMarginTop());
        if (viewData.getBelow()!=null && !viewData.getBelow().equals("")) {
            minY += getMaxX(viewData.getBelow(), containersData);
        }
        return minY;
    }

    private float getMaxX(String containerId, Map<String, DesignData> containersData) {
        DesignData viewData = containersData.get(containerId);
        float maxX  = Float.parseFloat(viewData.getWidth());
        maxX += Float.parseFloat(viewData.getMarginLeft());
        if (viewData.getToRightOf()!=null && !viewData.getToRightOf().equals("")) {
            maxX += getMaxX(viewData.getToRightOf(), containersData);
        }
        return maxX;
    }


    private float getMinX(String containerId, Map<String, DesignData> containersData) {
        DesignData viewData = containersData.get(containerId);
        float minX = Float.parseFloat(viewData.getMarginLeft());
        if (viewData.getToRightOf()!=null && !viewData.getToRightOf().equals("") ) {
            minX += getMaxX(viewData.getToRightOf(), containersData);
        }
        return minX;
    }

    private void centerHorizontally(View view, PercentRelativeLayout.LayoutParams params){
        params.addRule(PercentRelativeLayout.CENTER_HORIZONTAL);
    }

    private void centerVertcally(View view, PercentRelativeLayout.LayoutParams params){
        params.addRule(PercentRelativeLayout.CENTER_VERTICAL);
    }

    private void centerInSuperview(View view, PercentRelativeLayout.LayoutParams params){
        params.addRule(PercentRelativeLayout.CENTER_IN_PARENT);
    }

    private void setAspectRatio(View view, float aspectRatio, PercentRelativeLayout.LayoutParams params){
        params.getPercentLayoutInfo().aspectRatio = aspectRatio;
    }



}
