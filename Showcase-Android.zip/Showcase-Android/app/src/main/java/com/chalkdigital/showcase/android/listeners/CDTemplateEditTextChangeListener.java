package com.chalkdigital.showcase.android.listeners;

import com.chalkdigital.showcase.android.utilities.templateparser.CDTemplateEditText;

/**
 * Created by arungupta on 21/10/16.
 */

public interface CDTemplateEditTextChangeListener {
    void textChanged(CDTemplateEditText cdTemplateEditText);
}
