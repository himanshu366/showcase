package com.chalkdigital.showcase.android.model.data;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * Created by arungupta on 07/07/16.
 */

public class SignupData implements Parcelable {

    private int appId;
    private long companyId;
    private long createDate;
    private String email;
    private boolean firstLogin;
    private long id;
    private long lastLogin;
    private String password;
    private boolean primaryContact;
    private String chalk;
    private int roleId;
    private int status;
    private String title;
    private long updateByUserId;
    private long updateDate;
    private String username;

    public int getAppId() {
        return appId;
    }

    public void setAppId(int appId) {
        this.appId = appId;
    }

    public long getCompanyId() {
        return companyId;
    }

    public void setCompanyId(long companyId) {
        this.companyId = companyId;
    }

    public long getCreateDate() {
        return createDate;
    }

    public void setCreateDate(long createDate) {
        this.createDate = createDate;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public boolean isFirstLogin() {
        return firstLogin;
    }

    public void setFirstLogin(boolean firstLogin) {
        this.firstLogin = firstLogin;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public long getLastLogin() {
        return lastLogin;
    }

    public void setLastLogin(long lastLogin) {
        this.lastLogin = lastLogin;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public boolean isPrimaryContact() {
        return primaryContact;
    }

    public void setPrimaryContact(boolean primaryContact) {
        this.primaryContact = primaryContact;
    }

    public String getChalk() {
        return chalk;
    }

    public void setChalk(String chalk) {
        this.chalk = chalk;
    }

    public int getRoleId() {
        return roleId;
    }

    public void setRoleId(int roleId) {
        this.roleId = roleId;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public long getUpdateByUserId() {
        return updateByUserId;
    }

    public void setUpdateByUserId(long updateByUserId) {
        this.updateByUserId = updateByUserId;
    }

    public long getUpdateDate() {
        return updateDate;
    }

    public void setUpdateDate(long updateDate) {
        this.updateDate = updateDate;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }


    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeInt(this.appId);
        dest.writeLong(this.companyId);
        dest.writeLong(this.createDate);
        dest.writeString(this.email);
        dest.writeByte(this.firstLogin ? (byte) 1 : (byte) 0);
        dest.writeLong(this.id);
        dest.writeLong(this.lastLogin);
        dest.writeString(this.password);
        dest.writeByte(this.primaryContact ? (byte) 1 : (byte) 0);
        dest.writeString(this.chalk);
        dest.writeInt(this.roleId);
        dest.writeInt(this.status);
        dest.writeString(this.title);
        dest.writeLong(this.updateByUserId);
        dest.writeLong(this.updateDate);
        dest.writeString(this.username);
    }

    public SignupData() {
    }

    protected SignupData(Parcel in) {
        this.appId = in.readInt();
        this.companyId = in.readLong();
        this.createDate = in.readLong();
        this.email = in.readString();
        this.firstLogin = in.readByte() != 0;
        this.id = in.readLong();
        this.lastLogin = in.readLong();
        this.password = in.readString();
        this.primaryContact = in.readByte() != 0;
        this.chalk = in.readString();
        this.roleId = in.readInt();
        this.status = in.readInt();
        this.title = in.readString();
        this.updateByUserId = in.readLong();
        this.updateDate = in.readLong();
        this.username = in.readString();
    }

    public static final Creator<SignupData> CREATOR = new Creator<SignupData>() {
        @Override
        public SignupData createFromParcel(Parcel source) {
            return new SignupData(source);
        }

        @Override
        public SignupData[] newArray(int size) {
            return new SignupData[size];
        }
    };
}
