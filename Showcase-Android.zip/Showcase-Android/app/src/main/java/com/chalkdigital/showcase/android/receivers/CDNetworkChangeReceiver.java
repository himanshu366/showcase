package com.chalkdigital.showcase.android.receivers;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

import com.chalkdigital.showcase.android.activities.HomeActivity;

public class CDNetworkChangeReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
        Intent newIntent = new Intent(context, HomeActivity.class);
        newIntent.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
        newIntent.putExtras(intent.getExtras());
        context.startActivity(intent);
    }
}
