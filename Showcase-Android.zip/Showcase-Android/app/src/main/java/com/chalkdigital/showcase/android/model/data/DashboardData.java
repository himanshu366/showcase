package com.chalkdigital.showcase.android.model.data;

import android.os.Parcel;
import android.os.Parcelable;

import java.util.List;

/**
 * Created by arungupta on 13/09/16.
 */
public class DashboardData implements Parcelable {
    private AggregatedStats accountStats;
    private List<Campaign> campaigns;

    public AggregatedStats getAccountStats() {
        return accountStats;
    }

    public void setAccountStats(AggregatedStats accountStats) {
        this.accountStats = accountStats;
    }

    public List<Campaign> getCampaigns() {
        return campaigns;
    }

    public void setCampaigns(List<Campaign> campaigns) {
        this.campaigns = campaigns;
    }


    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeParcelable(this.accountStats, flags);
        dest.writeTypedList(this.campaigns);
    }

    public DashboardData() {
    }

    protected DashboardData(Parcel in) {
        this.accountStats = in.readParcelable(AggregatedStats.class.getClassLoader());
        this.campaigns = in.createTypedArrayList(Campaign.CREATOR);
    }

    public static final Creator<DashboardData> CREATOR = new Creator<DashboardData>() {
        @Override
        public DashboardData createFromParcel(Parcel source) {
            return new DashboardData(source);
        }

        @Override
        public DashboardData[] newArray(int size) {
            return new DashboardData[size];
        }
    };
}