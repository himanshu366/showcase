package com.chalkdigital.showcase.android.utilities.util;

import android.content.ContentResolver;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.location.Address;
import android.net.Uri;
import android.util.Base64;
import android.util.Log;
import android.widget.EditText;
import android.widget.TextView;

import com.chalkdigital.showcase.android.R;
import com.chalkdigital.showcase.android.contants.Constants;
import com.chalkdigital.showcase.android.contants.Keys;
import com.chalkdigital.showcase.android.contants.Params;
import com.chalkdigital.showcase.android.model.data.AggregatedStats;
import com.chalkdigital.showcase.android.model.data.Campaign;
import com.chalkdigital.showcase.android.model.data.DashboardData;
import com.chalkdigital.showcase.android.retrofit.CDRetrofit;
import com.chalkdigital.showcase.android.retrofit.CDService;
import com.chalkdigital.showcase.android.retrofit.CDServiceCallback;
import com.google.gson.Gson;
import com.google.gson.stream.JsonReader;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.lang.reflect.Field;
import java.lang.reflect.Type;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import java.util.regex.Pattern;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Response;

/**
 * Created by arungupta on 22/06/16.
 */
public class Util {

    private static final String TAG = "agent image download";
    public static SharedPreferences getSharedPreferences(Context context){
        return context.getSharedPreferences("CDPREFERENCES", Context.MODE_PRIVATE);
    }

    public static Editor getSharedPreferencesEditor(Context context){
        SharedPreferences preferences = Util.getSharedPreferences(context);
        return preferences.edit();
    }
    public static void zlog(String s) {
        Log.d("lol", s);
    }

    public static void putStringToSharedPreferences(String key, String value, Context context){
        Editor editor = Util.getSharedPreferencesEditor(context);
        editor.putString(key, value);
        editor.commit();
    }

    public static void removeFromSharedPreferences(String key, Context context){
        Editor editor = Util.getSharedPreferencesEditor(context);
        editor.remove(key);
        editor.commit();
    }

    public static void putObjectToSharedPreferences(String key, Object object, Context context){
        Editor editor = Util.getSharedPreferencesEditor(context);
        editor.putString(key, new Gson().toJson(object));
        editor.commit();
    }

    public static void putBooleanToSharedPreferences(String key, Boolean value, Context context){
        Editor editor = Util.getSharedPreferencesEditor(context);
        editor.putBoolean(key, value);
        editor.commit();
    }

    public static void putIntegerToSharedPreferences(String key, Integer value, Context context){
        Editor editor = Util.getSharedPreferencesEditor(context);
        editor.putInt(key, value);
        editor.commit();
    }


    public static void putLongToSharedPreferences(String key, long value, Context context){
        Editor editor = Util.getSharedPreferencesEditor(context);
        editor.putLong(key, value);
        editor.commit();
    }


    public static String getStringFromSharedPreferences(String key, String defaultValue, Context context){
        SharedPreferences preferences = Util.getSharedPreferences(context);
        return preferences.getString(key, defaultValue);
    }

    public static <T> T getObjectFromSharedPreferences(String key, Type typeOfT, Context context){
        SharedPreferences preferences = Util.getSharedPreferences(context);
        return new Gson().fromJson(preferences.getString(key, ""), typeOfT);
    }

    public static Boolean getBooleanFromSharedPreferences(String key, Boolean defaultValue, Context context){
        SharedPreferences preferences = Util.getSharedPreferences(context);
        return preferences.getBoolean(key, defaultValue);
    }

    public static Integer getIntegerFromSharedPreferences(String key, Integer defaultValue, Context context){
        SharedPreferences preferences = Util.getSharedPreferences(context);
        return preferences.getInt(key, defaultValue);
    }

    public static Long getLongFromSharedPreferences(String key, long defaultValue, Context context){
        SharedPreferences preferences = Util.getSharedPreferences(context);
        return preferences.getLong(key, defaultValue);
    }

    public static Map<String , String> getHeaders(Context context){
        HashMap<String , String > map = new HashMap<String, String>();
        map.put(Keys.KEY_Device_OS, "Android");
        map.put(Keys.KEY_CONTENT_TYPE, "application/json");
        String token = Util.getStringFromSharedPreferences(Keys.KEY_TOKEN, "", context);
        if (token != null && token.length()>0){
            map.put(Keys.KEY_AUTHORIZATION, "Bearer "+token);
        }
        return map;
    }

    public static boolean checkEmailValidation(String email) {
        Pattern PATTERN = Pattern.compile(Constants.EMAIL_REGEX);
        return PATTERN.matcher(email).matches();
    }

    public static String encodeBitmapToBase64(Bitmap image, Bitmap.CompressFormat compressFormat, int quality)
    {
        ByteArrayOutputStream byteArrayOS = new ByteArrayOutputStream();
        image.compress(compressFormat, quality, byteArrayOS);
        return Base64.encodeToString(byteArrayOS.toByteArray(), Base64.DEFAULT);
    }

    public static String encodeImageFileToBase64(Uri uri, Bitmap.CompressFormat compressFormat, int quality)
    {
        return Util.encodeBitmapToBase64(BitmapFactory.decodeFile(uri.getPath()), compressFormat, quality);
    }

    public static Bitmap decodeBase64ToBitmap(String input)
    {
        byte[] decodedBytes = Base64.decode(input, 0);
        return BitmapFactory.decodeByteArray(decodedBytes, 0, decodedBytes.length);
    }

    public static String getLastUuidString(Context context){
        return  Util.getStringFromSharedPreferences("uuidString", "", context);
    }

    public static String getNewUuidString(Context context){
        String uuid = UUID.randomUUID().toString();
        Util.putStringToSharedPreferences("uuidString", uuid, context);
        return uuid;
    }

    public static final String md5(final String s) {
        final String MD5 = "MD5";
        try {
            // Create MD5 Hash
            MessageDigest digest = java.security.MessageDigest
                    .getInstance(MD5);
            digest.update(s.getBytes());
            byte messageDigest[] = digest.digest();

            // Create Hex String
            StringBuilder hexString = new StringBuilder();
            for (byte aMessageDigest : messageDigest) {
                String h = Integer.toHexString(0xFF & aMessageDigest);
                while (h.length() < 2)
                    h = "0" + h;
                hexString.append(h);
            }
            return hexString.toString();

        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        }
        return "";
    }

    public static void downloadAgentImage(final Context context){
      CDServiceCallback callbackListener = new CDServiceCallback() {
          @Override
          public void onNetworkRequestResponse(Call call, Response response, int apiType, int tagValue, String tagString) {
              writeResponseBodyToDisk((ResponseBody)response.body(), context);
          }

          @Override
          public void onNetworkRequestFailure(Call call, Throwable t, int apiType, int tagValue, String tagString) {

          }
      };
        Uri agentImageUrl = Uri.parse(Util.getStringFromSharedPreferences(Keys.KEY_AGENTIMAGEURL, "", context));

        CDService.performRequest(CDRetrofit.createInstance(Params.CD_baseUrl, null),
                "downloadFile", ResponseBody.class,
                new Class[] {String.class}, new Object[]{Util.getStringFromSharedPreferences(Keys.KEY_AGENTIMAGEURL, "", context)},
                callbackListener, 0, 0, null, null);

    }

    private static boolean writeResponseBodyToDisk(ResponseBody body, Context context) {
        try {
            // todo change the file location/name according to your needs
            File file = new File(context.getExternalFilesDir(null) + File.separator + "agentImage.png");
            InputStream inputStream = null;
            OutputStream outputStream = null;

            try {
                byte[] fileReader = new byte[4096];

                long fileSize = body.contentLength();
                long fileSizeDownloaded = 0;

                inputStream = body.byteStream();
                outputStream = new FileOutputStream(file);

                while (true) {
                    int read = inputStream.read(fileReader);

                    if (read == -1) {
                        break;
                    }

                    outputStream.write(fileReader, 0, read);

                    fileSizeDownloaded += read;

                    Log.d(TAG, "file download: " + fileSizeDownloaded + " of " + fileSize);
                    putStringToSharedPreferences(Keys.KEY_AGENTIMAGEPATH, file.getPath(), context);
                }

                outputStream.flush();

                return true;
            } catch (IOException e) {
                return false;
            } finally {
                if (inputStream != null) {
                    inputStream.close();
                }

                if (outputStream != null) {
                    outputStream.close();
                }
            }
        } catch (IOException e) {
            return false;
        }
    }

    public static boolean isEqualOrAboveApiLevel(int apiLevel){
        if (Integer.valueOf(android.os.Build.VERSION.SDK)<apiLevel){
            return false;
        }
        return true;
    }



    public static String getCurrentDateTime(){
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
        return dateFormat.format(Calendar.getInstance().getTime());
    }

    public static Date getDateFromString(String date){
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
        try {
            return dateFormat.parse(date);
        } catch (ParseException e) {
            return Calendar.getInstance().getTime();
        }
    }

    public static String getStringFromDate(Date date){
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
        return dateFormat.format(date);
    }

    public static Date getDateFromYMDString(String date){
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        try {
            return dateFormat.parse(date);
        } catch (ParseException e) {
            return Calendar.getInstance().getTime();
        }
    }

    public static String getYMDStringFromDate(Date date){
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        return dateFormat.format(date);
    }

    public static Date getDateFromFullStyleString(String date){
        SimpleDateFormat dateFormat = new SimpleDateFormat("EEEE, MMM dd, yyyy");
        try {
            return dateFormat.parse(date);
        } catch (ParseException e) {
            return Calendar.getInstance().getTime();
        }
    }

    public static String getFullStyleStringFromDate(Date date){
        SimpleDateFormat dateFormat = new SimpleDateFormat("EEEE, MMM dd, yyyy");
        return dateFormat.format(date);
    }

    public static String getFormatedStringForDateRange(Date date1, Date date2){
        SimpleDateFormat dateFormat2 = new SimpleDateFormat("MMM dd, yyyy");
        if (date1.compareTo(date2)<0 ) {
            SimpleDateFormat dateFormat1 = new SimpleDateFormat("MMM dd");
            return "Duration: "+dateFormat1.format(date1)+" - "+dateFormat2.format(date2);
        }else{
            return "Date: "+dateFormat2.format(date1);
        }
    }

    public static String getStringForDateRange(Date date1, Date date2){
        SimpleDateFormat dateFormat2 = new SimpleDateFormat("MMM dd, yyyy");
        if (date1.compareTo(date2)<0) {
            SimpleDateFormat dateFormat1 = new SimpleDateFormat("MMM dd");
            return dateFormat1.format(date1)+" - "+dateFormat2.format(date2);
        }else{
            return dateFormat2.format(date1);
        }
    }


    public static Date getLineChartDateFromString(String string){
       return getDateFromYMDString(string);
    }

    public static String getLineChartStringFromDate(Date date){
        SimpleDateFormat dateFormat = new SimpleDateFormat("MMM-dd");
        return dateFormat.format(date);
    }


    public static String getYearMonthDate(Date date){
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");
        return dateFormat.format(date);
    }

    public static Date getDateByModifyingYMD(Date date, int years, int months, int days){
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        calendar.add(Calendar.DATE, days);
        calendar.add(Calendar.MONTH, months);
        calendar.add(Calendar.YEAR, years);
        return calendar.getTime();
    }

    public static Date getDateFromYMD(int year, int month, int dayOfMonth){
        Calendar calendar = Calendar.getInstance();
        calendar.set(year, month, dayOfMonth);
        return calendar.getTime();
    }


    public static String getDateFilterName(int index, Context context){
        String name = "Today";
        switch (index) {
            case -2:
                name = "All Dates";
                break;
            case 0:
                name = "Today";
                break;
            case 1:
                name = "Yesterday";
                break;
            case 2:
                name = "Last 7 Days";
                break;
            case 3:
                name = "Last 6 Months";
                break;
            case 4:
                name = "Custom Dates";
                break;
            case 5:
                name = context.getResources().getString(R.string.StartDateLabel);
                break;
            case 6:
                name = context.getResources().getString(R.string.EndDateLabel);
                break;
            default:
                break;
        }
        return name;
    }

    public static Date getStartDateForIndex(int index){
        Date date;
        switch (index) {
            case 0:
                date = Calendar.getInstance().getTime();
                break;
            case 1:
                date = getDateByModifyingYMD(Calendar.getInstance().getTime(), 0, 0, -1);
                break;
            case 2:
                date = getDateByModifyingYMD(Calendar.getInstance().getTime(), 0, 0, -7);
                break;
            case 3:
                date = getDateByModifyingYMD(Calendar.getInstance().getTime(), 0, -1, 0);
                break;
            case 4:
                date = getDateByModifyingYMD(Calendar.getInstance().getTime(), 0, -6, 0);
                break;
            default:
                date = Calendar.getInstance().getTime();
                break;
        }
        return date;

    }

    public static String getNumberFormattedPercentageTextWithFloat(float floatingNumnber){
        DecimalFormat decimalFormat = new DecimalFormat("00.00");
        return decimalFormat.format(floatingNumnber);
    }

    public static String getCommaSepratedNumber(long number){
        return NumberFormat.getNumberInstance(Locale.US).format(number);
    }

    public static void clearUserData(Context context){
        Util.removeFromSharedPreferences(Keys.KEY_AGENTIMAGEURL, context);
        Util.removeFromSharedPreferences(Keys.KEY_AGENTINFO, context);
        Util.removeFromSharedPreferences(Keys.KEY_CREDITBALANCE, context);
        Util.removeFromSharedPreferences(Keys.KEY_TOKEN, context);
        Util.removeFromSharedPreferences(Keys.KEY_REFRESHTOKEN, context);
        Util.removeFromSharedPreferences(Keys.KEY_USERID, context);
        Util.removeFromSharedPreferences(Keys.KEY_FIRSTNAME, context);
        Util.removeFromSharedPreferences(Keys.KEY_LASTNAME, context);
        Util.removeFromSharedPreferences(Keys.KEY_USERNAME, context);
        Util.removeFromSharedPreferences(Keys.KEY_PASSWORD, context);
        Util.removeFromSharedPreferences(Keys.KEY_AGENTIMAGEPATH, context);
    }

    public static String getReverseAddress(Address address){
        StringBuilder builder = new StringBuilder();
        if (address.getSubThoroughfare()!=null && address.getSubThoroughfare().length()>0) {
            builder.append(address.getSubThoroughfare()+", ");
        }
        if (address.getThoroughfare()!=null && address.getThoroughfare().length()>0) {
            builder.append(address.getThoroughfare()+", ");
        }
        if (address.getSubLocality()!=null && address.getSubLocality().length()>0) {
            builder.append(address.getSubLocality()+", ");
        }
        if (address.getLocality()!=null && address.getLocality().length()>0) {
            builder.append(address.getLocality()+", ");
        }
        if (address.getAdminArea()!=null && address.getAdminArea().length()>0) {
            builder.append(address.getAdminArea()+", ");
        }
        if (address.getPostalCode()!=null && address.getPostalCode().length()>0) {
            builder.append(address.getPostalCode()+", ");
        }
        if (address.getCountryName()!=null && address.getCountryName().length()>0) {
            builder.append(address.getCountryName()+", ");
        }

        if (builder.length()>=2) {
            builder.delete(builder.length()-2,builder.length()-1);
        }
        return builder.toString();
    }


    public static void setCursorDrawableColor(EditText editText, int color) {
        try {
            Field fCursorDrawableRes =
                    TextView.class.getDeclaredField("mCursorDrawableRes");
            fCursorDrawableRes.setAccessible(true);
            int mCursorDrawableRes = fCursorDrawableRes.getInt(editText);
            Field fEditor = TextView.class.getDeclaredField("mEditor");
            fEditor.setAccessible(true);
            Object editor = fEditor.get(editText);
            Class<?> clazz = editor.getClass();
            Field fCursorDrawable = clazz.getDeclaredField("mCursorDrawable");
            fCursorDrawable.setAccessible(true);

            Drawable[] drawables = new Drawable[2];
            Resources res = editText.getContext().getResources();
            drawables[0] = res.getDrawable(mCursorDrawableRes);
            drawables[1] = res.getDrawable(mCursorDrawableRes);
            drawables[0].setColorFilter(color, PorterDuff.Mode.SRC_IN);
            drawables[1].setColorFilter(color, PorterDuff.Mode.SRC_IN);
            fCursorDrawable.set(editor, drawables);
        } catch (final Throwable ignored) {
        }
    }


    public static String  resourceToPath(Context context, int resID) {
        return Uri.parse(ContentResolver.SCHEME_ANDROID_RESOURCE + "://" +
                context.getResources().getResourcePackageName(resID) + '/' +
                context.getResources().getResourceTypeName(resID) + '/' +
                context.getResources().getResourceEntryName(resID) ).toString();
    }

    public static void logout(Context context){
        Util.removeFromSharedPreferences(Keys.KEY_AGENTINFO, context);
        Util.removeFromSharedPreferences(Keys.KEY_CREDITBALANCE, context);
        Util.removeFromSharedPreferences(Keys.KEY_TOKEN, context);
        Util.removeFromSharedPreferences(Keys.KEY_REFRESHTOKEN, context);
        Util.removeFromSharedPreferences(Keys.KEY_USERID, context);
        Util.removeFromSharedPreferences(Keys.KEY_FIRSTNAME, context);
        Util.removeFromSharedPreferences(Keys.KEY_LASTNAME, context);
        Util.removeFromSharedPreferences(Keys.KEY_USERNAME, context);
    }


}
