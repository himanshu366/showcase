package com.chalkdigital.showcase.android.listeners;

/**
 * Created by arungupta on 08/11/16.
 */

public interface DesignTemplateItemClickListener {

    void switchTemplate(int previousSelectedIndex, int currentSelectedIndex);
}
