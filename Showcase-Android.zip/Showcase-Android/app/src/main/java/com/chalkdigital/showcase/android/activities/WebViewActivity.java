package com.chalkdigital.showcase.android.activities;

import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import com.chalkdigital.showcase.android.R;
import com.chalkdigital.showcase.android.contants.ApiType;
import com.chalkdigital.showcase.android.contants.Keys;
import com.chalkdigital.showcase.android.contants.Params;
import com.chalkdigital.showcase.android.utilities.util.Util;

/**
 * An example full-screen activity that shows and hides the system UI (i.e.
 * status bar and navigation/system bar) with user interaction.
 */
public class WebViewActivity extends BaseActivity{
    WebView mWebView;
    String mUrl;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_web_view);
        mWebView = (WebView)findViewById(R.id.webView);
        mWebView.setVisibility(View.INVISIBLE);
        mUrl = getIntent().getExtras().getString(Keys.KEY_URL);
        WebSettings webSettings = mWebView.getSettings();
        webSettings.setCacheMode(WebSettings.LOAD_NO_CACHE);
        mWebView.setWebViewClient(new WebViewClient(){
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                if (Params.linkedInRedirecthUrl.contains(request.getUrl().getHost())) {
                    sendResultWithAuthToken(request.getUrl());
                    return true;
                }
                return false;
            }
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                Uri uri = Uri.parse(url);
                String host = uri.getHost();
                if (Params.linkedInRedirecthUrl.contains(host)) {
                    sendResultWithAuthToken(uri);
                    return true;
                }
                return false;
            }

            @Override
            public void onPageStarted(WebView view, String url, Bitmap favicon) {
                showAnimations(ApiType.APITYPE_LINKED_IN_SIGN_IN);
                super.onPageStarted(view, url, favicon);
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                hideAnimations(ApiType.APITYPE_LINKED_IN_SIGN_IN);
                super.onPageFinished(view, url);
                mWebView.setVisibility(View.VISIBLE);
            }

            @Override
            public void onLoadResource(WebView view, String url) {
                super.onLoadResource(view, url);
                mWebView.setVisibility(View.VISIBLE);
            }

            @Override
            public void onReceivedHttpError(WebView view, WebResourceRequest request, WebResourceResponse errorResponse) {
                hideAnimations(ApiType.APITYPE_LINKED_IN_SIGN_IN);
                super.onReceivedHttpError(view, request, errorResponse);
            }
        });
    }

    private void sendResultWithAuthToken(Uri uri) {
        hideAnimations(ApiType.APITYPE_LINKED_IN_SIGN_IN);
        String state = uri.getQueryParameter("state");
        if (state.equals(Util.getLastUuidString(this))){
            String authToken = uri.getQueryParameter("code");
            if (authToken!=null && !authToken.equals("")){
                Intent returnIntent = new Intent();
                returnIntent.putExtra("authToken",authToken);
                setResult(RESULT_OK,returnIntent);
                finish();
            }else{
                Intent returnIntent = new Intent();
                returnIntent.putExtra("error","authFailed");
                setResult(RESULT_CANCELED,returnIntent);
                finish();
            }

        }
    }

    @Override
    protected void onStart() {
        super.onStart();
        mWebView.loadUrl(mUrl);
    }

    @Override
    public void onBackPressed() {
        Intent returnIntent = new Intent();
        returnIntent.putExtra("error","cancelledByUser");
        setResult(RESULT_CANCELED,returnIntent);
        finish();
//        super.onBackPressed();
    }


}
