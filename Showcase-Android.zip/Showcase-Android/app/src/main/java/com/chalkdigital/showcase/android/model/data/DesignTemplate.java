package com.chalkdigital.showcase.android.model.data;

import android.os.Parcel;
import android.os.Parcelable;

import java.io.Serializable;

/**
 * Created by arungupta on 13/10/16.
 */

public class DesignTemplate implements Parcelable,Serializable{
    private long id;
    private String appName;
    private String name;
    private String imageurl;
    private String infoInJson;

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getAppName() {
        return appName;
    }

    public void setAppName(String appName) {
        this.appName = appName;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getImageurl() {
        return imageurl;
    }

    public void setImageurl(String imageurl) {
        this.imageurl = imageurl;
    }

    public String getInfoInJson() {
        return infoInJson;
    }

    public void setInfoInJson(String infoInJson) {
        this.infoInJson = infoInJson;
    }


    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeLong(this.id);
        dest.writeString(this.appName);
        dest.writeString(this.name);
        dest.writeString(this.imageurl);
        dest.writeString(this.infoInJson);
    }

    public DesignTemplate() {
    }

    protected DesignTemplate(Parcel in) {
        this.id = in.readLong();
        this.appName = in.readString();
        this.name = in.readString();
        this.imageurl = in.readString();
        this.infoInJson = in.readString();
    }

    public static final Creator<DesignTemplate> CREATOR = new Creator<DesignTemplate>() {
        @Override
        public DesignTemplate createFromParcel(Parcel source) {
            return new DesignTemplate(source);
        }

        @Override
        public DesignTemplate[] newArray(int size) {
            return new DesignTemplate[size];
        }
    };
}
