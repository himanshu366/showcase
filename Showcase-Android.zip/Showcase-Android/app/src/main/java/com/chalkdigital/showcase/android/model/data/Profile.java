package com.chalkdigital.showcase.android.model.data;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * Created by arungupta on 22/06/16.
 */
public class Profile implements Parcelable{
    private long createdByUserId;
    private String email;
    private String fax;
    private String firstName;
    private long id;
    private String lastName;
    private String middleName;
    private long mobilePhone;
    private String cell;
    private String photoUrl;
    private int status;
    private String title;
    private long updateByUserId;
    private long updateDate;
    private long userid;
    private String workPhone;

    public long getCreatedByUserId() {
        return createdByUserId;
    }

    public void setCreatedByUserId(long createdByUserId) {
        this.createdByUserId = createdByUserId;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getFax() {
        return fax;
    }

    public void setFax(String fax) {
        this.fax = fax;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getMiddleName() {
        return middleName;
    }

    public void setMiddleName(String middleName) {
        this.middleName = middleName;
    }

    public long getMobilePhone() {
        return mobilePhone;
    }

    public void setMobilePhone(long mobilePhone) {
        this.mobilePhone = mobilePhone;
    }

    public String getCell() {
        return cell;
    }

    public void setCell(String cell) {
        this.cell = cell;
    }

    public String getPhotoUrl() {
        return photoUrl;
    }

    public void setPhotoUrl(String photoUrl) {
        this.photoUrl = photoUrl;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public long getUpdateByUserId() {
        return updateByUserId;
    }

    public void setUpdateByUserId(long updateByUserId) {
        this.updateByUserId = updateByUserId;
    }

    public long getUpdateDate() {
        return updateDate;
    }

    public void setUpdateDate(long updateDate) {
        this.updateDate = updateDate;
    }

    public long getUserid() {
        return userid;
    }

    public void setUserid(long userid) {
        this.userid = userid;
    }

    public String getWorkPhone() {
        return workPhone;
    }

    public void setWorkPhone(String workPhone) {
        this.workPhone = workPhone;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeLong(this.createdByUserId);
        dest.writeString(this.email);
        dest.writeString(this.fax);
        dest.writeString(this.firstName);
        dest.writeLong(this.id);
        dest.writeString(this.lastName);
        dest.writeString(this.middleName);
        dest.writeLong(this.mobilePhone);
        dest.writeString(this.cell);
        dest.writeString(this.photoUrl);
        dest.writeInt(this.status);
        dest.writeString(this.title);
        dest.writeLong(this.updateByUserId);
        dest.writeLong(this.updateDate);
        dest.writeLong(this.userid);
        dest.writeString(this.workPhone);
    }

    public Profile() {
    }

    protected Profile(Parcel in) {
        this.createdByUserId = in.readLong();
        this.email = in.readString();
        this.fax = in.readString();
        this.firstName = in.readString();
        this.id = in.readLong();
        this.lastName = in.readString();
        this.middleName = in.readString();
        this.mobilePhone = in.readLong();
        this.cell = in.readString();
        this.photoUrl = in.readString();
        this.status = in.readInt();
        this.title = in.readString();
        this.updateByUserId = in.readLong();
        this.updateDate = in.readLong();
        this.userid = in.readLong();
        this.workPhone = in.readString();
    }

    public static final Creator<Profile> CREATOR = new Creator<Profile>() {
        @Override
        public Profile createFromParcel(Parcel source) {
            return new Profile(source);
        }

        @Override
        public Profile[] newArray(int size) {
            return new Profile[size];
        }
    };
}
