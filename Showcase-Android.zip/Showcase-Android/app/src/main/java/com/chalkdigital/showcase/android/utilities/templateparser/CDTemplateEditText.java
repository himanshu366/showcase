package com.chalkdigital.showcase.android.utilities.templateparser;

import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.util.AttributeSet;
import android.view.Gravity;

import com.chalkdigital.showcase.android.model.data.DesignData;

/**
 * Created by arungupta on 05/10/16.
 */

public class CDTemplateEditText extends androidx.appcompat.widget.AppCompatEditText {

    public DesignData properties;
    public boolean firstEntry = true;
    private OnEditorActionListener mEditorListener;

    public CDTemplateEditText(Context context) {
        super(context);
    }
    public CDTemplateEditText(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public CDTemplateEditText(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }

    public void format(){
        int gravity = Gravity.CENTER;
        String alignmentString = properties.getAlignMent();
        if (alignmentString == null || alignmentString.equals("")) {
            properties.setAlignMent(TemplateParser.CENTER);
            alignmentString = TemplateParser.CENTER;
        }
        if (alignmentString.equals(TemplateParser.RIGHT))
            gravity = Gravity.END;
        else if (alignmentString.equals(TemplateParser.LEFT))
            gravity = Gravity.START;

        setGravity(gravity);
        String textSize = properties.getFontSize();
        float size = 12.0f;
        if (textSize!=null && !textSize.equals("")){
            size = Float.parseFloat(textSize);
        }
        setTextSize(size);

        String lineSpacingString = properties.getFontLineSpacing();
        float lineSpacing = 0.0f;
        if (lineSpacingString!=null && !lineSpacingString.equals("")){
            lineSpacing = Float.parseFloat(lineSpacingString);
        }
        setLineSpacing(lineSpacing, 1);

        if (android.os.Build.VERSION.SDK_INT>=21){
            String charSpacingString = properties.getFontCharSpacing();
            float charSpacing = 0.0f;
            if (charSpacingString!=null && !charSpacingString.equals("")){
                charSpacing = Float.parseFloat(charSpacingString);
            }
            setLetterSpacing(charSpacing/10.0f);
        }

        String textColor = properties.getTextColor();
        if (textColor!=null && !textColor.equals("")){
            setTextColor(Color.parseColor("#"+textColor));
        }

        String fontName = properties.getFontName();
        if (fontName != null && !fontName.equals("")){
            setTypeface(Typeface.create(fontName,Typeface.NORMAL));
        }
    }
}
