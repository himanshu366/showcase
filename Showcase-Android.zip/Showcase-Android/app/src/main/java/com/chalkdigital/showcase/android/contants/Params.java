package com.chalkdigital.showcase.android.contants;

/**
 * Created by arungupta on 20/06/16.
 */
public class Params {
    public static final String CD_baseUrl                  = "https://cms-api.chalkdigital.com";
    public static final String Template_baseUrl            = "http://s3.amazonaws.com/chalkiosapp/";
    public static final String port                        = "";
    public static final String realTimeImpUrl              = "wss://ws-realtime.chalkdigital.com";
    public static final String recentAdsUrl                = "https://reporting.chalkdigital.com/stats/latest/v2";
    public static final String accountsUrl                 = "https://reporting.chalkdigital.com/account/list/v2";
    public static final String CD_frontendUrl              = "https://ads.chalkdigital.com";
    public static final String frontendPort                = ":8082";
    public static final String landingPageHost             = "http://cddev.chalkdigital.com:8085";
    public static final String frontendAuthorisationKey    = "Q2hAMWtEaWdpdEAx";
    public static final String companyId                   = "bhhscalifornia";
    public static final String companyKey                  = "22812864";
    public static final String customAdEmailId             = "customadchalkdigital.com";
    public static final String paypal_client_id            = "AWm71RD2pBUFY67TbHw2CpzP-6hw7BaCsd2oVemD8PwlMjmFPqSBgtPglagM";
    public static final String kPayPalEnvironment          = "";
    public static final String twitter_key                 = "QnRIrXFFLdEC4HaJD5QvkLY0G";
    public static final String twitter_secret              = "0cbOeyU3RDkO27h0mSaYX5X09Go2xozNk9mfsKdqpPUKGC0VKP";
    public static final String linkedInClientId            = "75cb4dfgozg1xz";
    public static final String linkedInSecret              = "iVHndVvXZJmZvA7B";
    public static final String linkedInOAuthUrl            = "https://www.linkedin.com";
    public static final String linkedInRedirecthUrl        = "http://redirect.oauth.com";
    public static final String linkedInProfileUrl          = "https://api.linkedin.com";
    public static final String supportMail                 = "arunchalkdigital.com";
    public static final String googleApiKey                = "AIzaSyCXJSFX97e0yhP-Nmro3V9QFmYUT-u1Vgg";
    public static final String mintApiToken                = "414acfc4b587d326c81edab";
    public static final String mintApiKey                  = "00135cad";
    public static final String appName                     = "Chalk Portal";//Chalk Portal App
    public static final String portalName                  = "ads";
    public static final String record_id                   = "replace_your_id";
    public static final double radiusTargetingMultiplier   = 1.609344; //km to miles.
}
