package com.chalkdigital.showcase.android.retrofit;

import android.content.Context;

import com.chalkdigital.showcase.android.contants.Constants;
import com.chalkdigital.showcase.android.contants.Params;
import com.chalkdigital.showcase.android.utilities.util.Util;

import java.io.IOException;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import okhttp3.Interceptor;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.logging.HttpLoggingInterceptor;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

/**
 * Created by arungupta on 20/06/16.
 */
public class CDRetrofit{
    private static Retrofit backendRetrofit;
    private static Retrofit frontendRetrofit;

    public static Retrofit getSharedBackendAPIInstance(final Context context){
        if (backendRetrofit == null) {
            backendRetrofit = CDRetrofit.createSharedInstance(Params.CD_baseUrl, context.getApplicationContext());
        }
        return backendRetrofit;
    }

    public static Retrofit getSharedFrontendAPIInstance(final Context context){
        if (frontendRetrofit == null){
            frontendRetrofit = CDRetrofit.createSharedInstance(Params.CD_frontendUrl, context.getApplicationContext());
        }
        return frontendRetrofit;
    }

    public static Retrofit createInstance(String baseUrl, final Map<String, String> requestHeaders){
        OkHttpClient.Builder builder = new OkHttpClient().newBuilder();
        builder.readTimeout(Constants.CONSTANT_READ_TIMEOUT_INTERVAL, TimeUnit.SECONDS);
        builder.connectTimeout(Constants.CONSTANT_CONNECTION_TIMEOUT_INTERVAL, TimeUnit.SECONDS);
        if (requestHeaders!=null){
            builder.addInterceptor(new Interceptor() {
                @Override
                public Response intercept(Interceptor.Chain chain) throws IOException {
                    Request.Builder builder = chain.request().newBuilder();
                    for (String key: requestHeaders.keySet()) {
                        builder.addHeader(key, requestHeaders.get(key));
                    }
                    builder.method(chain.request().method(), chain.request().body());
                    Request request = builder.build();
                    return chain.proceed(request);
                }
            });
        }
        HttpLoggingInterceptor interceptor = new HttpLoggingInterceptor();
        interceptor.setLevel(HttpLoggingInterceptor.Level.HEADERS);
        builder.addNetworkInterceptor(interceptor);
        return new Retrofit.Builder().baseUrl(baseUrl).addConverterFactory(GsonConverterFactory.create()).client(builder.build()).build();
    }

    public static Retrofit createSharedInstance(String baseUrl, final Context context){
            OkHttpClient.Builder builder = new OkHttpClient().newBuilder();
            builder.readTimeout(Constants.CONSTANT_READ_TIMEOUT_INTERVAL, TimeUnit.SECONDS);
            builder.connectTimeout(Constants.CONSTANT_CONNECTION_TIMEOUT_INTERVAL, TimeUnit.SECONDS);
            if (context!=null){
                builder.addInterceptor(new Interceptor() {
                    @Override
                    public Response intercept(Interceptor.Chain chain) throws IOException {
                        Request.Builder builder = chain.request().newBuilder();
                        Map<String, String> requestHeaders = Util.getHeaders(context);
                        for (String key: requestHeaders.keySet()) {
                            builder.addHeader(key, requestHeaders.get(key));
                        }
                        builder.method(chain.request().method(), chain.request().body());
                        Request request = builder.build();
                        return chain.proceed(request);
                    }
                });
            }
            HttpLoggingInterceptor interceptor = new HttpLoggingInterceptor();
            interceptor.setLevel(HttpLoggingInterceptor.Level.HEADERS);
            builder.addNetworkInterceptor(interceptor);
            return new Retrofit.Builder().baseUrl(baseUrl).addConverterFactory(GsonConverterFactory.create()).client(builder.build()).build();
    }



}
