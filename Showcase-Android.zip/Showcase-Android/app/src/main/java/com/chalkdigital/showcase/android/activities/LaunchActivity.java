package com.chalkdigital.showcase.android.activities;

import android.content.Intent;
import android.os.Bundle;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.chalkdigital.showcase.android.contants.Keys;
import com.chalkdigital.showcase.android.utilities.util.Util;

/**
 * An example full-screen activity that shows and hides the system UI (i.e.
 * status bar and navigation/system bar) with user interaction.
 */
public class LaunchActivity extends AppCompatActivity {
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (!Util.getStringFromSharedPreferences(Keys.KEY_TOKEN, "", getApplicationContext()).equals("")){
            startActivity(new Intent(this, HomeActivity.class));//DesignActivity
        }else{
            startActivity(new Intent(this, SignInActivity.class));//SignInActivity
        }
        finish();
    }
}
