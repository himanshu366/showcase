package com.chalkdigital.showcase.android.model.response;

import android.os.Parcel;

import com.chalkdigital.showcase.android.model.data.LoginData;

/**
 * Created by arungupta on 09/08/16.
 */
public class SigninResponse extends BaseResponse {
    private LoginData response;

    public LoginData getResponse() {
        return response;
    }

    public void setResponse(LoginData response) {
        this.response = response;
    }


    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        super.writeToParcel(dest, flags);
        dest.writeParcelable(this.response, flags);
    }

    public SigninResponse() {
    }

    protected SigninResponse(Parcel in) {
        super(in);
        this.response = in.readParcelable(LoginData.class.getClassLoader());
    }

    public static final Creator<SigninResponse> CREATOR = new Creator<SigninResponse>() {
        @Override
        public SigninResponse createFromParcel(Parcel source) {
            return new SigninResponse(source);
        }

        @Override
        public SigninResponse[] newArray(int size) {
            return new SigninResponse[size];
        }
    };
}
