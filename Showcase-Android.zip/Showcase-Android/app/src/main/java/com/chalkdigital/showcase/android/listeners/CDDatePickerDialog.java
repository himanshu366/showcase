package com.chalkdigital.showcase.android.listeners;

import android.app.DatePickerDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.widget.DatePicker;
import android.widget.EditText;

import com.chalkdigital.showcase.android.utilities.util.Util;

import java.util.Calendar;
import java.util.Date;

/**
 * Created by arungupta on 03/10/16.
 */

public class CDDatePickerDialog {


    private DatePickerDialog datePickerDialog;
    private EditText mEditText;

    public CDDatePickerDialog(final EditText editText, Context context, Long minDate, Long maxDate, Date selectedDate) {
        mEditText = editText;
        DatePickerDialog.OnDateSetListener onDateSetListener = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                editText.setText(Util.getFullStyleStringFromDate(Util.getDateFromYMD(year, month, dayOfMonth)));
            }
        };
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(selectedDate);
        datePickerDialog = new DatePickerDialog(context, onDateSetListener, calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DAY_OF_MONTH));
        if (minDate!=null)
            datePickerDialog.getDatePicker().setMinDate(minDate);
        if (maxDate!=null)
            datePickerDialog.getDatePicker().setMaxDate(maxDate);
        datePickerDialog.setOnCancelListener(new DialogInterface.OnCancelListener() {
            @Override
            public void onCancel(DialogInterface dialog) {
                mEditText.clearFocus();
            }
        });

        datePickerDialog.setOnDismissListener(new DialogInterface.OnDismissListener() {
            @Override
            public void onDismiss(DialogInterface dialog) {
                mEditText.clearFocus();
            }
        });

        datePickerDialog.setCanceledOnTouchOutside(true);

    }

    public void show(){
        datePickerDialog.show();
    }
}
