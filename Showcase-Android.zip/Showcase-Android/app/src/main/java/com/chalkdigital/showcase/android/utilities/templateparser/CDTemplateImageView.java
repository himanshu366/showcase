package com.chalkdigital.showcase.android.utilities.templateparser;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.ImageView;

import com.chalkdigital.showcase.android.model.data.DesignData;

/**
 * Created by arungupta on 05/10/16.
 */

public class CDTemplateImageView extends ImageView {
    public DesignData properties;
    public CDTemplateImageView(Context context) {
        super(context);
    }
    public CDTemplateImageView(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public CDTemplateImageView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }
}
