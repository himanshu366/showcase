package com.chalkdigital.showcase.android.utilities.styledesigner;

import android.annotation.TargetApi;
import android.content.Context;
import android.graphics.Typeface;
import android.view.View;
import android.widget.TextView;

import com.chalkdigital.showcase.android.contants.Keys;
import com.chalkdigital.showcase.android.utilities.util.Util;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by arungupta on 27/06/16.
 */



public class StyleDesigner {

    public enum TextStyle{
        Normal(0), Bold(1), Italic(2);
        private int value;
        TextStyle(int value) {
            this.value = value;
        }
    }

    public static Map<String , Object> getAttributes(String styleName, Context context){
        HashMap<String , Object> map = new HashMap<String, Object>();
        map.put(Keys.KEY_FONTNAME, context.getResources().getString(context.getResources().getIdentifier(styleName+"FontName", "string",context.getPackageName())));
        map.put(Keys.KEY_FONTSIZE, context.getResources().getDimension(context.getResources().getIdentifier(styleName+"Size", "dimen",context.getPackageName())));
        map.put(Keys.KEY_LINESPACING, context.getResources().getDimension(context.getResources().getIdentifier(styleName+"LineSpacing", "dimen",context.getPackageName())));
        map.put(Keys.KEY_CHARSPACING, context.getResources().getDimension(context.getResources().getIdentifier(styleName+"CharSpacing", "dimen",context.getPackageName())));
        return map;
    }

    public static void setStyle(View view, String styleName, int color, int gravity, TextStyle textStyle, Context context){
        Map<String, Object> map = StyleDesigner.getAttributes(styleName, context);
        if (view.getClass().isAssignableFrom(TextView.class)){
            TextView textview = (TextView) view;
            setStyle(view, styleName,color, textStyle, context);
            textview.setGravity(gravity);
        }
    }

    public static void setStyle(View view, String styleName, TextStyle textStyle, int gravity, Context context){
        Map<String, Object> map = StyleDesigner.getAttributes(styleName, context);
        if (view.getClass().isAssignableFrom(TextView.class)){
            TextView textview = (TextView) view;
            setStyle(view, styleName, textStyle, context);
            textview.setGravity(gravity);

        }
    }

    public static void setStyle(View view, String styleName, int color, TextStyle textStyle, Context context){
        Map<String, Object> map = StyleDesigner.getAttributes(styleName, context);
        if (view.getClass().isAssignableFrom(TextView.class)){
            TextView textview = (TextView) view;
            setStyle(view, styleName, textStyle, context);
            textview.setTextColor(color);

        }
    }

    @TargetApi(21)
    public static void setStyle(View view, String styleName, TextStyle textStyle, Context context){
        Map<String, Object> map = StyleDesigner.getAttributes(styleName, context);
        if (view.getClass().isAssignableFrom(TextView.class)){
            TextView textview = (TextView) view;
            if (textStyle!=null){
                textview.setTypeface(Typeface.createFromAsset(context.getAssets(), map.get(Keys.KEY_FONTNAME).toString()), textStyle.value);
            }else{
                textview.setTypeface(Typeface.createFromAsset(context.getAssets(), map.get(Keys.KEY_FONTNAME).toString()));
            }
            textview.setTextSize((float)map.get(Keys.KEY_FONTSIZE));
            textview.setLineSpacing((float)map.get(Keys.KEY_LINESPACING), 1);
            if (Util.isEqualOrAboveApiLevel(21)){
                textview.setLetterSpacing((float)map.get(Keys.KEY_CHARSPACING));
            }
        }
    }


}
