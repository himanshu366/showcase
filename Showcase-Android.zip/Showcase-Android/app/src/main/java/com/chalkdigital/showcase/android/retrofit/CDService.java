package com.chalkdigital.showcase.android.retrofit;

import android.content.Context;
import android.util.Log;

import com.chalkdigital.showcase.android.retrofit.service.CDApi;
import com.chalkdigital.showcase.android.utilities.util.Util;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;

/**
 * Created by arungupta on 22/06/16.
 */
public class CDService {
    public static <T> T performRequest(Retrofit retrofit,
                                       String declaredMethodName, final Class<T> returnObjectType, Class[] classArgs , Object[] valueArgs, final CDServiceCallback callbackListener,
                                       final int apiType, final int tagValue,
                                       final String tagString, String responseType){
        CDApi api = retrofit.create(CDApi.class);
        Class[] cArg = new Class[0];
        //cArg[0] = Callback.class;
        try {
            Method declaredMethod = CDApi.class.getDeclaredMethod(declaredMethodName, classArgs);
            Call<T> call = (Call<T>) declaredMethod.invoke(api, valueArgs);
            call.enqueue( new Callback<T>() {
                @Override
                public void onResponse(Call<T> call, Response<T> response) {
                    Log.d("retrofit service", "cd_service_success");
                    callbackListener.onNetworkRequestResponse(call, response, apiType, tagValue, tagString);
                }
                @Override
                public void onFailure(Call<T> call, Throwable t) {
                    Log.d("retrofit service", "cd_service_failure");
                    callbackListener.onNetworkRequestFailure(call, t, apiType, tagValue, tagString);
                }
            });
        } catch (NoSuchMethodException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        } catch (InvocationTargetException e) {
            e.printStackTrace();
        } finally {
        }
        return null;
    }

    public static <T> T performBackendRequest(Context context,
                                       String declaredMethodName, final Class<T> returnObjectType, Class[] classArgs , Object[] valueArgs, final CDServiceCallback callbackListener,
                                              final int apiType, final int tagValue,
                                              final String tagString, String responseType){
        CDService.performRequest(CDRetrofit.getSharedBackendAPIInstance(context), declaredMethodName, returnObjectType, classArgs, valueArgs, callbackListener, apiType, tagValue, tagString, responseType);
        return null;
    }

    public static <T> T performBackendRequest(Context context,
                                              String declaredMethodName, final Class<T> returnObjectType, Class[] classArgs,
                                              Object[] valueArgs, final CDServiceCallback callbackListener,
                                              final int apiType){
        CDService.performBackendRequest(context, declaredMethodName, returnObjectType, classArgs, valueArgs, callbackListener, apiType, 0, null, null);
        return null;
    }
    public static <T> T performBackendRequest(Context context,
                                              String declaredMethodName, final Class<T> returnObjectType, final CDServiceCallback callbackListener,
                                              final int apiType){
        CDService.performBackendRequest(context, declaredMethodName, returnObjectType, null, null, callbackListener, apiType);
        return null;
    }

}
