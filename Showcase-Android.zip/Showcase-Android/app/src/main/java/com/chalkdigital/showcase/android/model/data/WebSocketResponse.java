package com.chalkdigital.showcase.android.model.data;

public class WebSocketResponse {
    private WebSocketResponseData message;

    public WebSocketResponseData getMessage() {
        return message;
    }

    public void setMessage(WebSocketResponseData message) {
        this.message = message;
    }
}
