package com.chalkdigital.showcase.android.activities;

import android.content.Intent;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.chalkdigital.showcase.android.R;
import com.chalkdigital.showcase.android.contants.Keys;
import com.chalkdigital.showcase.android.contants.Params;
import com.chalkdigital.showcase.android.model.response.SigninResponse;
import com.chalkdigital.showcase.android.retrofit.CDRetrofit;
import com.chalkdigital.showcase.android.retrofit.CDService;
import com.chalkdigital.showcase.android.retrofit.CDServiceCallback;
import com.chalkdigital.showcase.android.utilities.util.Util;

import java.util.HashMap;

import retrofit2.Call;
import retrofit2.Response;
import retrofit2.Retrofit;

public class BaseActivity extends AppCompatActivity implements CDServiceCallback {

    private ViewGroup mProgressIndicator;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
//        this.performRequest(CDRetrofit.getSharedBackendAPIInstance(this), "getBooks",((new ArrayList<Book>()).getClass()), null, null, this, null, null, 0, null, 0, null, null);
//        HashMap<String , String > map = new HashMap<String , String >();
//        map.put("username", "arun");
//        map.put("password", "arun");
//        map.put(Keys.KEY_APPNAME, Params.appName);
//        CDService.performRequest(CDRetrofit.getSharedBackendAPIInstance(this, 0), "login", LoginResponse.class, new Class[] {HashMap.class}, new Object[] {map}, this, null, null, 0, null, 0, null, null);
//        try {
//        CDApi api = new Retrofit.Builder().baseUrl("https://dl.dropboxusercontent.com").addConverterFactory(GsonConverterFactory.create()).build().create(CDApi.class);
//        Call<List<Book>> call= api.getBooks();
//            call.enqueue(new Callback<List<Book>>(){
//                @Override
//                public void onNetworkRequestSuccess(Call<List<Book>> call,  Response<List<Book>> response) {
//                    System.out.println("here");
//                }
//                @Override
//                public void onNetworkRequestFailure( Call<List<Book>> call, Throwable t) {
//                    System.out.println("failure");
//                }
//            });
//        } catch (Exception e) {
//            System.out.println("exception");
//            e.printStackTrace();
//        } finally {
//
//        }
    }

    final <T> T performRequest(Retrofit retrofit,
                   String declaredMethodName, final Class<T> returnObjectType, Class[] classArgs , Object[] valueArgs, final CDServiceCallback callbackListener,
                   final int apiType, final int tagValue,
                   final String tagString, String responseType){
        showAnimations(apiType, tagValue, tagString);
        return CDService.performRequest(retrofit,
                declaredMethodName, returnObjectType, classArgs , valueArgs, callbackListener,
        apiType, tagValue,
        tagString, responseType);

    }


    protected void performLogin(HashMap<String, String> params, int apitype){
        params.put(Keys.KEY_APPNAME, Params.appName);
        params.put(Keys.KEY_PORTALNAME, Params.portalName);
        performRequest(CDRetrofit.getSharedBackendAPIInstance(this), "signin", SigninResponse.class, new Class[] {HashMap.class}, new Object[] {params}, this, apitype, 0, null, null);
    }

    @Override
    public void onNetworkRequestResponse(Call call, Response response, int apiType, int tagValue,
                           String tagString) {
        if (response.raw().code() == 401){
            Util.logout(this);
            if (this.getClass() != SignInActivity.class){
                startActivity(new Intent(this, SignInActivity.class));
                finish();
            }
            return;
        }else if (response.raw().code() !=200)
            onNetworkRequestFailure(call, new Throwable("server code "+response.raw().code()), apiType, tagValue, tagString);
        onNetworkRequestSuccess(call, response, apiType, tagValue, tagString);
    }

    @Override
    public void onNetworkRequestFailure(Call call, Throwable t, int apiType, int tagValue,
                          String tagString) {
        hideAnimations(apiType, tagValue, tagString);
    }

    public void onNetworkRequestSuccess(Call call, Response response, int apiType, int tagValue,
                                        String tagString){
        hideAnimations(apiType, tagValue, tagString);
    }

    protected void showAnimations(final int apiType, final int tagValue,
                                  final String tagString){

        final ViewGroup viewGroup = (ViewGroup) ((ViewGroup) this
        .getWindow().getDecorView().getRootView());
        if (mProgressIndicator ==null){
            mProgressIndicator = getProgressIndicator(viewGroup);
            viewGroup.addView(mProgressIndicator, -1);
        }
        mProgressIndicator.setVisibility(View.VISIBLE);

    }

    private ViewGroup getProgressIndicator(ViewGroup viewGroup){

        LayoutInflater inflater = getLayoutInflater();
        return (ViewGroup) inflater.inflate(R.layout.view_progressindicator, viewGroup,
                false);
    }

    protected void hideAnimations(final int apiType, final int tagValue,
                                  final String tagString){
        if (mProgressIndicator !=null){
            mProgressIndicator.setVisibility(View.INVISIBLE);
        }
    }

    protected void hideAnimations(final int apiType){
        hideAnimations(apiType, 0, "");
    }

    protected void showAnimations(final int apiType){
        showAnimations(apiType, 0, "");
    }

    void showMessage(int resourceId){
        Toast.makeText(this, resourceId, Toast.LENGTH_SHORT).show();
    }

    void showMessage(String message){
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }
}

