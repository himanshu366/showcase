package com.chalkdigital.showcase.android.customcomponents;

import android.telephony.PhoneNumberUtils;
import android.text.Editable;
import android.text.Selection;
import android.text.TextWatcher;

import java.util.Locale;

/**
 * Created by arungupta on 10/07/16.
 */

public class CDPhoneTextWatcher implements TextWatcher {
    static private int sFormatType;
    private boolean mFormatting;
    private boolean mDeletingDot;
    private int mDotStart;
    private boolean mDeletingBackward;

    public CDPhoneTextWatcher() {
        sFormatType = PhoneNumberUtils.getFormatTypeForLocale(Locale.getDefault());
    }

    @Override
    public synchronized void afterTextChanged(Editable text) {
        // Make sure to ignore calls to afterTextChanged caused by the work done below
        if (!mFormatting) {
            mFormatting = true;

            // If deleting the hyphen, also delete the char before or after that
            if (mDeletingDot && mDotStart > 0) {
                if (mDeletingBackward) {
                    if (mDotStart - 1 < text.length()) {
                        text.delete(mDotStart - 1, mDotStart);
                    }
                } else if (mDotStart < text.length()) {
                    text.delete(mDotStart, mDotStart + 1);
                }
            }else{
                String strippedNumber = text.toString().replaceAll("[^0-9]", "");
                int digits = strippedNumber.length();
                if (digits<=10){
                    if (digits==0)
                        text.clear();
                    else if (digits <=3)
                        text.replace(0, text.length(), strippedNumber);
                    else if (digits<=6)
                        text.replace(0, text.length(), String.format("%s.%s", strippedNumber.substring(0,3), strippedNumber.substring(3)));
                    else
                        text.replace(0, text.length(), String.format("%s.%s.%s", strippedNumber.substring(0,3), strippedNumber.substring(3,6), strippedNumber.substring(6)));


                }

            }

            mFormatting = false;
        }
    }

    @Override
    public void beforeTextChanged(CharSequence s, int start, int count, int after) {
        // Check if the user is deleting a hyphen
        if (!mFormatting) {
            // Make sure user is deleting one char, without a selection
            final int selStart = Selection.getSelectionStart(s);
            final int selEnd = Selection.getSelectionEnd(s);
            if (s.length() > 1 // Can delete another character
                    && count == 1 // Deleting only one character
                    && after == 0 // Deleting
                    && s.charAt(start) == '.' // a dot
                    && selStart == selEnd) { // no selection
                mDeletingDot = true;
                mDotStart = start;
                // Check if the user is deleting forward or backward
                if (selStart == start + 1) {
                    mDeletingBackward = true;
                } else {
                    mDeletingBackward = false;
                }
            } else {
                mDeletingDot = false;
            }
        }
    }

    @Override
    public void onTextChanged(CharSequence s, int start, int before, int count) {

    }
}
