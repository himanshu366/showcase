package com.chalkdigital.showcase.android.utilities.templateparser;

import android.content.Context;
import androidx.percentlayout.widget.PercentRelativeLayout;
import android.util.AttributeSet;

import com.chalkdigital.showcase.android.model.data.DesignData;

/**
 * Created by arungupta on 14/10/16.
 */

public class CDTemplateButton extends PercentRelativeLayout {
    public DesignData properties;
    public CDTemplateButton(Context context) {
        super(context);
    }
    public CDTemplateButton(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public CDTemplateButton(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }
}
