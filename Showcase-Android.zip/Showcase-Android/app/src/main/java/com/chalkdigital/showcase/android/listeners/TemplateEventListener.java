package com.chalkdigital.showcase.android.listeners;

import android.text.TextWatcher;
import android.view.View;

/**
 * Created by arungupta on 05/10/16.
 */

public interface TemplateEventListener extends View.OnClickListener, View.OnFocusChangeListener {
//removed TextWatcher
}
