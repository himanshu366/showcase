package com.chalkdigital.showcase.android.utilities.templateparser;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.ImageButton;

import com.chalkdigital.showcase.android.model.data.DesignData;

/**
 * Created by arungupta on 05/10/16.
 */

public class CDTemplateImageButton extends ImageButton {

    public DesignData properties;
    public boolean hasData;
    public CDTemplateImageButton(Context context) {
        super(context);
    }

    public CDTemplateImageButton(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public CDTemplateImageButton(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }
}
