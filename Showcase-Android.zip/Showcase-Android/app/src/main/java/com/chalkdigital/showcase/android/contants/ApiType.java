package com.chalkdigital.showcase.android.contants;

/**
 * Created by arungupta on 22/06/16.
 */
public class ApiType {
    public static final int APITYPE_LOGIN                                = 0;
    public static final int APITYPE_AGENT_IMAGE_UPLOAD                   = 1;
    public static final int APITYPE_SIGN_UP                              = 2;
    public static final int APITYPE_SIGN_IN                              = 3;
    public static final int APITYPE_DASHBOARD                            = 4;
    public static final int APITYPE_PRICING                              = 5;
    public static final int APITYPE_PUBLISH                              = 6;
    public static final int APITYPE_ZIP_CITY_SUGESSIONS                  = 7;
    public static final int APITYPE_ZIP_CITY_BOUNDARY_DATA               = 8;
    public static final int APITYPE_DESIGN_TEMPLATES                     = 9;
    public static final int APITYPE_SMALL_TEMPLATES                      = 10;
    public static final int APITYPE_AVAILS                               = 11;
    public static final int APITYPE_CHANGE_PASSWORD                      = 12;
    public static final int APITYPE_FORGOT_PASSWORD                      = 13;
    public static final int APITYPE_EDIT_PROFILE                         = 14;
    public static final int APITYPE_LANDING_PAGE_TEMPLATES               = 15;
    public static final int APITYPE_EMAIL_RECEIPT                        = 16;
    public static final int APITYPE_LINKED_IN_PROFILE                    = 17;
    public static final int APITYPE_LINKED_IN_ACCESS                     = 18;
    public static final int APITYPE_SUPPORT                              = 19;
    public static final int APITYPE_LINKED_IN_SIGN_IN                    = 20;
    public static final int APITYPE_TWITTER_SIGN_IN                      = 21;
    public static final int APITYPE_FACEBOOK_SIGN_IN                     = 22;
    public static final int APITYPE_URL_VERIFICATION                     = 23;
}
