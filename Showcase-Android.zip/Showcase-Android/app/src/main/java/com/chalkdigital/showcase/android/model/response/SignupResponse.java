package com.chalkdigital.showcase.android.model.response;

import android.os.Parcel;

import com.chalkdigital.showcase.android.model.data.SignupData;

/**
 * Created by arungupta on 07/07/16.
 */

public class SignupResponse extends BaseResponse {

    private SignupData response;

    public SignupData getResponse() {
        return response;
    }

    public void setResponse(SignupData response) {
        this.response = response;
    }


    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        super.writeToParcel(dest, flags);
        dest.writeParcelable(this.response, flags);
    }

    public SignupResponse() {
    }

    protected SignupResponse(Parcel in) {
        super(in);
        this.response = in.readParcelable(SignupData.class.getClassLoader());
    }

    public static final Creator<SignupResponse> CREATOR = new Creator<SignupResponse>() {
        @Override
        public SignupResponse createFromParcel(Parcel source) {
            return new SignupResponse(source);
        }

        @Override
        public SignupResponse[] newArray(int size) {
            return new SignupResponse[size];
        }
    };
}
