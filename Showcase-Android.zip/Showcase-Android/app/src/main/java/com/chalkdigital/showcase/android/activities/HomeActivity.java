package com.chalkdigital.showcase.android.activities;

import android.Manifest;
import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ValueAnimator;
import android.content.Context;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;
import android.location.Location;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.NetworkRequest;
import android.os.Bundle;

import com.chalkdigital.showcase.android.contants.ApiType;
import com.chalkdigital.showcase.android.contants.Keys;
import com.chalkdigital.showcase.android.contants.Params;
import com.chalkdigital.showcase.android.logging.CDAdLog;
import com.chalkdigital.showcase.android.model.data.RealTimeImpressionData;
import com.chalkdigital.showcase.android.model.data.RealTimeImpressionResponse;
import com.chalkdigital.showcase.android.model.data.WebSocketResponse;
import com.chalkdigital.showcase.android.model.data.WebSocketResponseData;
import com.chalkdigital.showcase.android.model.response.SigninResponse;
import com.chalkdigital.showcase.android.utilities.util.Util;
import com.fonfon.kgeohash.GeoHash;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.CameraPosition;
import com.google.android.gms.maps.model.Circle;
import com.google.android.gms.maps.model.CircleOptions;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.VisibleRegion;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;

import androidx.annotation.ColorInt;
import androidx.annotation.NonNull;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.os.Handler;
import android.os.Message;
import android.text.TextUtils;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.widget.Toast;

import com.chalkdigital.showcase.android.R;
import com.google.gson.Gson;
import com.google.maps.android.SphericalUtil;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Timer;
import java.util.TimerTask;

import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.WebSocket;
import okhttp3.WebSocketListener;
import okio.ByteString;
import retrofit2.Call;

public class HomeActivity extends BaseActivity implements OnMapReadyCallback {
    private GoogleMap mMap;
    private static final int LOCATION_PERMISSION_REQUEST_CODE = 1;
    private OkHttpClient mOkHttpClient;
    private WebSocket mWebSocket;
    private ConnectionStateMonitor mConnectionStateMonitor;
    private Timer mWebSocketConnectionTimer;
    private Timer mAnnotationValidityTimer;
    private CDCameraMoveListener mCDCameraMoveListener;
    private int precision;
    private CD_SocketConnectionStatus mCDSocketConnectionStatus;
    private ArrayList<String> mFilterIds;
    private TimerHandler mTimerHandler;
    private HashMap<String, RealTimeImpressionData> mMapImpressions;
    private HashMap<String, Marker> mMarkers;

    private static final String REFRESH_ANNOTATION = "refresh";
    private static final String CONNECT_WEB_SOCKET = "connect";
    private static final String MSG_KEY = "msg_key";

    private enum CD_SocketConnectionStatus{
        CD_SocketConnectionConnected,
        CD_SocketConnectionClosed,
        CD_SocketConnectionFailed,
        CD_SocketConnectionConnecting;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mMarkers = new HashMap<>();
        mTimerHandler = new TimerHandler();
        mCDSocketConnectionStatus = CD_SocketConnectionStatus.CD_SocketConnectionClosed;
        mConnectionStateMonitor = new ConnectionStateMonitor();
        mConnectionStateMonitor.enable(this);
        mFilterIds = new ArrayList<>();
        setContentView(R.layout.activity_home);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        try {
            ((SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.map))
                    .getMapAsync(this);
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    private void disconnectWebSocket(){
        if (mWebSocket!=null){
            CDAdLog.d("disconnectWebSocket");
            mWebSocket.cancel();
            mOkHttpClient = null;
        }
    }

    private void connectWebSocket(){
        CDAdLog.d("connectWebSocket");
        if (mWebSocketConnectionTimer == null){
            TimerTask timerTask = new TimerTask() {
                @Override
                public void run() {
                    Message msg = mTimerHandler.obtainMessage();
                    Bundle bundle = new Bundle();
                    bundle.putString(MSG_KEY, CONNECT_WEB_SOCKET);
                    msg.setData(bundle);
                    mTimerHandler.sendMessage(msg);
                }
            };
            mWebSocketConnectionTimer = new Timer(true);
            mWebSocketConnectionTimer.scheduleAtFixedRate(timerTask, 0, 30000);
            return;
        }

        VisibleRegion visibleRegion = mMap.getProjection().getVisibleRegion();
        LatLng northEastPoint = visibleRegion.latLngBounds.northeast;
        LatLng southWestPoint = visibleRegion.latLngBounds.southwest;
        LatLng centerPoint = visibleRegion.latLngBounds.getCenter();

        double doubleDistance = SphericalUtil.computeDistanceBetween(northEastPoint, southWestPoint);
        double vDistance = Math.abs(doubleDistance);

        precision = 1;
        if (vDistance<5000) {
            precision = 9;
        }else if (vDistance<20000) {
            precision = 8;
        }else if (vDistance<100000) {
            precision = 7;
        }else if (vDistance<1000000){
            precision = 6;
        }else if (vDistance<5000000){
            precision = 5;
        }else if (vDistance<50000000){
            precision = 4;
        }else if (vDistance<150000000){
            precision = 3;
        }else if (vDistance<1500000000){
            precision = 2;
        }else{
            precision = 1;
        }

        if (mWebSocket!=null){
            if (mCDSocketConnectionStatus == CD_SocketConnectionStatus.CD_SocketConnectionConnected){
                HashMap<String, Object > message = new HashMap<>();
                message.put("level", precision+"");
                HashMap<String, Object > params = new HashMap<>();
                params.put("event", "zoom-level");
                params.put("message", message);
                mWebSocket.send(new Gson().toJson(params));

                message = new HashMap<>();
                message.put("radius", vDistance/2.0+"");
                message.put("latitude", centerPoint.latitude+"");
                message.put("longitude", centerPoint.longitude+"");
                if (mFilterIds.size()>0){
                    message.put("accountIds", mFilterIds);
                }
                params = new HashMap<>();
                params.put("event", "filters");
                params.put("message", message);
                mWebSocket.send(new Gson().toJson(params));


            }
            return;
        }

        String url = "";
        try {
            url = String.format("%s/ws/location/chalk:%s?z=%d&latitude=%f&longitude=%f&radius=%f", Params.realTimeImpUrl, URLEncoder.encode(Util.getStringFromSharedPreferences(Keys.KEY_TOKEN, "", this), "UTF-8"), precision, centerPoint.latitude, centerPoint.longitude, vDistance/2.0);
            if (mFilterIds.size()>0){
                url = url+String.format("&accountIds=%s", TextUtils.join(",", mFilterIds));
            }
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
        Request request = new Request.Builder().url(url).build();
        CDWebSocketListener listener = new CDWebSocketListener();
        mOkHttpClient = new OkHttpClient();
        mWebSocket = mOkHttpClient.newWebSocket(request, listener);
        mOkHttpClient.dispatcher().executorService().shutdown();
        mCDSocketConnectionStatus = CD_SocketConnectionStatus.CD_SocketConnectionConnecting;
    }


    @Override
    public void onMapReady(GoogleMap googleMap) {
        if (googleMap != null){
            mMap = googleMap;
            mCDCameraMoveListener = new CDCameraMoveListener();
            mMap.setOnCameraMoveListener(mCDCameraMoveListener);
            enableMyLocationIfPermitted();
        }
    }

    @Override
    public void onPointerCaptureChanged(boolean hasCapture) {

    }

    private void enableMyLocationIfPermitted() {
        if (ContextCompat.checkSelfPermission(this,
                Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.ACCESS_FINE_LOCATION,
                            Manifest.permission.ACCESS_FINE_LOCATION},
                    LOCATION_PERMISSION_REQUEST_CODE);
        } else if (mMap != null) {
            Task<Location> task = LocationServices.getFusedLocationProviderClient(this).getLastLocation();
            task.addOnCompleteListener(new OnCompleteListener<Location>() {
                @Override
                public void onComplete(@NonNull Task<Location> task) {

                   if (task.isComplete() && task.isSuccessful()){
                       Location location = task.getResult();
                       mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(
                               new LatLng(location.getLatitude(),
                                       location.getLongitude()), 11));
//                       RealTimeImpressionData data = new RealTimeImpressionData();
//                       data.setLatitude(location.getLatitude());
//                       data.setLongitude(location.getLongitude());
//                       data.setImpressions(1);
//                       data.setClicks(0);
//                       showMarker(data);

                   }else{
                       showDefaultLocation();
                   }
                }

            });

        }
    }

    private void showDefaultLocation() {
        Toast.makeText(this, "", Toast.LENGTH_SHORT).show();
        Toast.makeText(this, "Location permission not granted, " +
                        "showing default location",
                Toast.LENGTH_SHORT).show();
        LatLng redmond = new LatLng(0, 0);
        mMap.moveCamera(CameraUpdateFactory.newLatLng(redmond));
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        switch (requestCode) {
            case LOCATION_PERMISSION_REQUEST_CODE: {
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    enableMyLocationIfPermitted();
                } else {
                    showDefaultLocation();
                }
                return;
            }

        }
    }

//    private GoogleMap.OnMyLocationButtonClickListener onMyLocationButtonClickListener =
//            new GoogleMap.OnMyLocationButtonClickListener() {
//                @Override
//                public boolean onMyLocationButtonClick() {
//                    mMap.setMinZoomPreference(15);
//                    return false;
//                }
//            };
//
//    private GoogleMap.OnMyLocationClickListener onMyLocationClickListener =
//            new GoogleMap.OnMyLocationClickListener() {
//                @Override
//                public void onMyLocationClick(@NonNull Location location) {
//
//                    mMap.setMinZoomPreference(12);
//
//
//                    CircleOptions circleOptions = new CircleOptions();
//                    circleOptions.center(new LatLng(location.getLatitude(),
//                            location.getLongitude()));
//
//                    circleOptions.radius(200);
//                    circleOptions.fillColor(Color.RED);
//                    circleOptions.strokeWidth(6);
//
//                    mMap.addCircle(circleOptions);
//                }
//            };

    private void checkAnnotationValidity(){

    }

    private Marker showMarker(final RealTimeImpressionData realTimeImpressionData, Marker oldMarker){
        final float density = HomeActivity.this.getResources().getDisplayMetrics().density;
        final Marker marker;
        if (oldMarker!=null)
            marker = oldMarker;
        else{
             marker = mMap.addMarker(new MarkerOptions()
                    .anchor(0.5f,0.5f)
                    .icon(BitmapDescriptorFactory.fromBitmap(Bitmap.createBitmap((int)(60*density), (int) (60*density), Bitmap.Config.ARGB_8888)))
                    .position(new LatLng(realTimeImpressionData.getLatitude(), realTimeImpressionData.getLongitude()))
                    .title(String.format("Imp %d Clicks %d", realTimeImpressionData.getImpressions(), realTimeImpressionData.getClicks())));
            marker.setTag(realTimeImpressionData);
            mMarkers.put(realTimeImpressionData.getGeohash(), marker);
        }

        final Paint paint = new Paint();
        paint.setStyle(Paint.Style.FILL_AND_STROKE);
        if (realTimeImpressionData.getClicks()>0) {
            paint.setColor(Color.GREEN);
            marker.setZIndex(102);
        }
        else if (realTimeImpressionData.getImpressions()>0) {
            paint.setColor(Color.RED);
            marker.setZIndex(101);
        }
        else if (realTimeImpressionData.getUniqueUsers()>0) {
            paint.setColor(Color.BLUE);
            marker.setZIndex(100);
        }
        paint.setStrokeWidth(density);
        paint.setAntiAlias(true);
        paint.setStrokeJoin(Paint.Join.ROUND);
        paint.setStrokeCap(Paint.Cap.ROUND);

        final ValueAnimator animator = ValueAnimator.ofFloat(0, 8);
        animator.setDuration(6000);
        animator.setStartDelay(100);
        animator.setInterpolator(new AccelerateDecelerateInterpolator());
        animator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {

            @Override
            public void onAnimationUpdate(final ValueAnimator animation) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        float animatedValue = (float) animation.getAnimatedValue();
                        if (animatedValue==8){
                            synchronized (HomeActivity.this){

                                animator.cancel();
                                mMapImpressions.remove(realTimeImpressionData.getGeohash());
                                marker.remove();
                                return;
                            }
                        }
                        int intScale = (int)animatedValue;
                        float scale = animatedValue - intScale;
                        float floatScale = scale/2*1.5f;
                        scale = scale+1;
                        final int width = (int) (density*20*scale);
                        final Bitmap bitmap = Bitmap.createBitmap(width, width, Bitmap.Config.ARGB_8888);
                        final Canvas canvas = new Canvas(bitmap);
                        canvas.drawColor(getResources().getColor(R.color.transparent));
                        if (animatedValue<2.001){
                            paint.setAlpha((int) (200*(1-floatScale)));
                            int radius = Math.min(canvas.getWidth(),canvas.getHeight()/2);
                            canvas.drawCircle(
                                    canvas.getWidth() / 2, // cx
                                    canvas.getHeight() / 2, // cy
                                    radius-2, // Radius
                                    paint // Paint
                            );
                            paint.setAlpha(255);
                        }else{
                            float animationAlpha = (float) ((6 - animatedValue+2)/6.0);
                            CDAdLog.d("animationAlpha ",  animationAlpha+"");
                            int alpha = (int) ((animationAlpha)*255);
//                            int alpha = (int) ((8 - animatedValue)/8*0.4 + realTimeImpressionData.getClicks()>0?0.6:0.3)*255;
                            paint.setAlpha(alpha);
                        }

                        canvas.drawCircle(
                                canvas.getWidth() / 2, // cx
                                canvas.getHeight() / 2, // cy
                                density*9-2, // Radius
                                paint // Paint
                        );
                        final Rect originalRect = new Rect(0, 0, bitmap.getWidth(), bitmap.getHeight());
                        canvas.drawBitmap(bitmap, originalRect, originalRect, null);
                        try {
                            marker.setIcon(BitmapDescriptorFactory.fromBitmap(bitmap));
                        } catch (Exception e) {
                            CDAdLog.d("valueanimator ", (float) animation.getAnimatedValue()+"");
                            e.printStackTrace();
                        }
                    }
                });

            }


        });

        animator.start();

        return marker;
    }

    private class CDWebSocketListener extends WebSocketListener{
        @Override
        public void onOpen(WebSocket webSocket, Response response) {
            mCDSocketConnectionStatus = CD_SocketConnectionStatus.CD_SocketConnectionConnected;
            if (mAnnotationValidityTimer == null){
                TimerTask annotationValidityTask = new TimerTask() {
                    @Override
                    public void run() {
                        checkAnnotationValidity();
                    }
                };

                mAnnotationValidityTimer = new Timer(true);
                mAnnotationValidityTimer.scheduleAtFixedRate(annotationValidityTask, 5000, 5000);
            }
        }

        @Override
        public void onMessage(WebSocket webSocket, String text) {
            CDAdLog.d("web socket message", text);
            if (text.contains("Connection Established")){
                return;
            }
            Gson gson = new Gson();
            WebSocketResponse webSocketResponse = gson.fromJson(text, WebSocketResponse.class);
            if (webSocketResponse.getMessage().getError_code() == 101){
                final HashMap<String, String> map = new HashMap<>();
                map.put("username", Util.getStringFromSharedPreferences(Keys.KEY_USERNAME, "", HomeActivity.this));
                map.put("password", Util.getStringFromSharedPreferences(Keys.KEY_PASSWORD, "", HomeActivity.this));
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        performLogin(map, ApiType.APITYPE_SIGN_IN);
                    }
                });
                return;
            }

            if (webSocketResponse!=null){
                WebSocketResponseData message = webSocketResponse.getMessage();
                if (message!=null && message.getStatus() == 0){
                    RealTimeImpressionResponse realTimeImpressionResponse = message.getResponse();
                    if (realTimeImpressionResponse!=null){
                        ArrayList<RealTimeImpressionData> data = realTimeImpressionResponse.getData();
                        if (data!=null && data.size()>0){
                            mMapImpressions = new HashMap<>();
                            for(RealTimeImpressionData d : data){
                                String geohash = (new GeoHash(d.getLatitude(), d.getLongitude(), precision).toString());
                                d.setGeohash(geohash);
                                mMapImpressions.put(geohash, d);
                            }

                            for (final String geohash: mMarkers.keySet()){
                                synchronized (HomeActivity.this){
                                    final Marker marker = mMarkers.get(geohash);
                                    if (mMapImpressions.keySet().contains(geohash)){

                                            runOnUiThread(new Runnable() {
                                                @Override
                                                public void run() {
                                                    RealTimeImpressionData newRealTimeImpressionData = mMapImpressions.get(geohash);
                                                    RealTimeImpressionData oldRealTimeImpressionData = (RealTimeImpressionData) marker.getTag();
                                                    if (oldRealTimeImpressionData!=null && (oldRealTimeImpressionData.getClicks()!=newRealTimeImpressionData.getClicks()||oldRealTimeImpressionData.getImpressions()!=newRealTimeImpressionData.getImpressions())){
                                                        oldRealTimeImpressionData.setImpressions(newRealTimeImpressionData.getImpressions());
                                                        oldRealTimeImpressionData.setClicks(newRealTimeImpressionData.getClicks());
                                                        showMarker(oldRealTimeImpressionData, marker);
                                                    }
                                                    mMapImpressions.remove(geohash);
                                                }
                                            });

                                    }
                                }
                            }

                            for (String key : mMapImpressions.keySet()){
                                final RealTimeImpressionData d = mMapImpressions.get(key);
                                runOnUiThread(new Runnable() {
                                    @Override
                                    public void run() {
                                        showMarker(d, null);
                                    }
                                });
                            }
                        }

                    }
                }
            }
        }

        @Override
        public void onMessage(WebSocket webSocket, ByteString bytes) {
            CDAdLog.d(bytes.utf8());
            super.onMessage(webSocket, bytes);
        }

        @Override
        public void onClosing(WebSocket webSocket, int code, String reason) {
            CDAdLog.d("failed", "code: "+code+" "+reason);
            super.onClosing(webSocket, code, reason);
        }

        @Override
        public void onClosed(WebSocket webSocket, int code, String reason) {
            CDAdLog.d("closed", "code: "+code+" "+reason);
            mCDSocketConnectionStatus = CD_SocketConnectionStatus.CD_SocketConnectionClosed;
            disconnectWebSocket();
            super.onClosed(webSocket, code, reason);
        }

        @Override
        public void onFailure(WebSocket webSocket, Throwable t, Response response) {
            CDAdLog.d("failure", "", t);
            mCDSocketConnectionStatus = CD_SocketConnectionStatus.CD_SocketConnectionFailed;
            disconnectWebSocket();
            super.onFailure(webSocket, t, response);
        }
    }

    private class ConnectionStateMonitor extends ConnectivityManager.NetworkCallback {

        final NetworkRequest networkRequest;

        public ConnectionStateMonitor() {
            networkRequest = new NetworkRequest.Builder().addTransportType(NetworkCapabilities.TRANSPORT_CELLULAR).addTransportType(NetworkCapabilities.TRANSPORT_WIFI).build();
        }

        public void enable(Context context) {
            ConnectivityManager connectivityManager = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
            connectivityManager.registerNetworkCallback(networkRequest , this);
        }

        // Likewise, you can have a disable method that simply calls ConnectivityManager.unregisterNetworkCallback(NetworkCallback) too.

        @Override
        public void onAvailable(Network network) {
            if (mMap!=null){
                connectWebSocket();
            }
        }

        @Override
        public void onLost(Network network) {

        }

    }

    private class CDCameraMoveListener implements GoogleMap.OnCameraMoveListener{
        @Override
        public void onCameraMove() {
            connectWebSocket();
        }
    }

    @Override
    protected void onDestroy() {
        if (mAnnotationValidityTimer!=null) {
            mAnnotationValidityTimer.purge();
            mAnnotationValidityTimer = null;
        }
        if (mWebSocketConnectionTimer!=null) {
            mWebSocketConnectionTimer.purge();
            mWebSocketConnectionTimer = null;
        }
        disconnectWebSocket();
        super.onDestroy();
    }


    @Override
    public void onNetworkRequestSuccess(Call call, retrofit2.Response response, int apiType, int tagValue, String tagString) {
        switch (apiType){
            case ApiType.APITYPE_SIGN_IN:
                SigninResponse signInResponse = (SigninResponse)response.body();
                if (signInResponse.getStatus() == 0){
                    Util.putStringToSharedPreferences(Keys.KEY_TOKEN, signInResponse.getResponse().getToken(), this);
                    Util.putStringToSharedPreferences(Keys.KEY_REFRESHTOKEN, signInResponse.getResponse().getRefreshToken(), this);

                    connectWebSocket();
                }else{
                    Toast.makeText(this, "Please try after some time.", Toast.LENGTH_SHORT).show();
                }
                break;
            default:break;
        }
        super.onNetworkRequestSuccess(call, response, apiType, tagValue, tagString);
    }

    @Override
    public void onNetworkRequestFailure(Call call, Throwable t, int apiType, int tagValue, String tagString) {
        switch (apiType){
            case ApiType.APITYPE_SIGN_IN:
                Toast.makeText(this, "Please try after some time.", Toast.LENGTH_SHORT).show();
                break;
            default:break;
        }
        super.onNetworkRequestFailure(call, t, apiType, tagValue, tagString);
    }

    private class TimerHandler extends Handler{
        @Override
        public void handleMessage(Message msg) {
            String message = msg.getData().getString(MSG_KEY);
            switch (message){
                case CONNECT_WEB_SOCKET:
                    if (mCDSocketConnectionStatus == CD_SocketConnectionStatus.CD_SocketConnectionFailed || mCDSocketConnectionStatus == CD_SocketConnectionStatus.CD_SocketConnectionClosed)
                        connectWebSocket();
                    break;
                case REFRESH_ANNOTATION:
                    break;
            }

        }
    }


}
