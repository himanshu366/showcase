package com.chalkdigital.showcase.android.retrofit;

import retrofit2.Call;
import retrofit2.Response;

/**
 * Created by arungupta on 21/06/16.
 */
public interface CDServiceCallback {

    public void onNetworkRequestResponse(Call call, Response response, int apiType, int tagValue,
                           String tagString);

    public void onNetworkRequestFailure(Call call, Throwable t, int apiType, int tagValue,
                          String tagString);
}
