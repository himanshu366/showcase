package com.chalkdigital.showcase.android.activities;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;

import com.chalkdigital.showcase.android.R;

public class ForgotPasswordActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forgot_password);
    }
}
