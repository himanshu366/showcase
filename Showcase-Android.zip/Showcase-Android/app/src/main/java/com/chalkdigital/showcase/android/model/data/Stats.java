package com.chalkdigital.showcase.android.model.data;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * Created by arungupta on 13/09/16.
 */
public class Stats implements Parcelable{
    private String dimension;
    private int click;
    private int map;
    private int drivingDirection;
    private int review;
    private int website;
    private float spend;
    private float publisherRevenue;
    private float advertiserSpend;
    private int impression;
    private int clicksToCall;

    public String getDimension() {
        return dimension;
    }

    public void setDimension(String dimension) {
        this.dimension = dimension;
    }

    public int getClick() {
        return click;
    }

    public void setClick(int click) {
        this.click = click;
    }

    public int getMap() {
        return map;
    }

    public void setMap(int map) {
        this.map = map;
    }

    public int getDrivingDirection() {
        return drivingDirection;
    }

    public void setDrivingDirection(int drivingDirection) {
        this.drivingDirection = drivingDirection;
    }

    public int getReview() {
        return review;
    }

    public void setReview(int review) {
        this.review = review;
    }

    public int getWebsite() {
        return website;
    }

    public void setWebsite(int website) {
        this.website = website;
    }

    public float getSpend() {
        return spend;
    }

    public void setSpend(float spend) {
        this.spend = spend;
    }

    public float getPublisherRevenue() {
        return publisherRevenue;
    }

    public void setPublisherRevenue(float publisherRevenue) {
        this.publisherRevenue = publisherRevenue;
    }

    public float getAdvertiserSpend() {
        return advertiserSpend;
    }

    public void setAdvertiserSpend(float advertiserSpend) {
        this.advertiserSpend = advertiserSpend;
    }

    public int getImpression() {
        return impression;
    }

    public void setImpression(int impression) {
        this.impression = impression;
    }

    public int getClicksToCall() {
        return clicksToCall;
    }

    public void setClicksToCall(int clicksToCall) {
        this.clicksToCall = clicksToCall;
    }


    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(this.dimension);
        dest.writeInt(this.click);
        dest.writeInt(this.map);
        dest.writeInt(this.drivingDirection);
        dest.writeInt(this.review);
        dest.writeInt(this.website);
        dest.writeFloat(this.spend);
        dest.writeFloat(this.publisherRevenue);
        dest.writeFloat(this.advertiserSpend);
        dest.writeInt(this.impression);
        dest.writeInt(this.clicksToCall);
    }

    public Stats() {
    }

    protected Stats(Parcel in) {
        this.dimension = in.readString();
        this.click = in.readInt();
        this.map = in.readInt();
        this.drivingDirection = in.readInt();
        this.review = in.readInt();
        this.website = in.readInt();
        this.spend = in.readFloat();
        this.publisherRevenue = in.readFloat();
        this.advertiserSpend = in.readFloat();
        this.impression = in.readInt();
        this.clicksToCall = in.readInt();
    }

    public static final Creator<Stats> CREATOR = new Creator<Stats>() {
        @Override
        public Stats createFromParcel(Parcel source) {
            return new Stats(source);
        }

        @Override
        public Stats[] newArray(int size) {
            return new Stats[size];
        }
    };
}
