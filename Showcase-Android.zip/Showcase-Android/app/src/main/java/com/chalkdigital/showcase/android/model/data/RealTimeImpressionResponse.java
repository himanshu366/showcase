package com.chalkdigital.showcase.android.model.data;

import java.util.ArrayList;

public class RealTimeImpressionResponse {
    private ArrayList<RealTimeImpressionData> data;

    public ArrayList<RealTimeImpressionData> getData() {
        return data;
    }

    public void setData(ArrayList<RealTimeImpressionData> data) {
        this.data = data;
    }
}
