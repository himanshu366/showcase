package com.chalkdigital.showcase.android.activities;

import android.content.Intent;
import android.graphics.Typeface;
import android.os.Bundle;
import androidx.appcompat.widget.Toolbar;
import android.text.Editable;
import android.text.Html;
import android.text.InputType;
import android.text.method.LinkMovementMethod;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;

import com.chalkdigital.showcase.android.R;
import com.chalkdigital.showcase.android.contants.ApiType;
import com.chalkdigital.showcase.android.contants.Keys;
import com.chalkdigital.showcase.android.contants.Params;
import com.chalkdigital.showcase.android.customcomponents.compoundviews.CDEditText;
import com.chalkdigital.showcase.android.customcomponents.compoundviews.CDEditTextListener;
import com.chalkdigital.showcase.android.model.response.SigninResponse;
import com.chalkdigital.showcase.android.retrofit.CDRetrofit;
import com.chalkdigital.showcase.android.utilities.util.Util;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;

import retrofit2.Call;
import retrofit2.Response;

public class SignInActivity extends BaseActivity implements CDEditTextListener {

    private String mScreenName;
    private ArrayList<Integer> mEditTextCountArr;
    private ArrayList<View> mContentViews;
    private final int mCellCount = 2;
    private Menu mMenu;
    private ImageView mLogoImageview;
    private String mLinkedInAccessToken;
    private CheckBox mTcCheckbox;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_in);
        setSupportActionBar((Toolbar) findViewById(R.id.toolbar));
        LinearLayout signInLinearLayout = (LinearLayout) findViewById(R.id.signin_Layout);
        LayoutInflater inflater = getLayoutInflater();
        ViewGroup header = (ViewGroup) inflater.inflate(R.layout.header_sign_in, signInLinearLayout,
                false);
        mLogoImageview = (ImageView) header.findViewById(R.id.logo_imageview);
        signInLinearLayout.addView(header);
        mScreenName = getResources().getString(R.string.SignInScreenName);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        mEditTextCountArr = new ArrayList<Integer>(Arrays.asList(new Integer[mCellCount]));
        mContentViews = new ArrayList<View>(Arrays.asList(new View[mCellCount]));

        for (int i=0; i<mCellCount; i++){
            View view = (View) inflater.inflate(R.layout.cd_edittext_listcell, signInLinearLayout, false);
            CDEditText rowView = (CDEditText) view.findViewById(R.id.cdEditText_cell);
            rowView.initialise(i, false, true, this, mScreenName);
            EditText editText = (EditText) rowView.findViewById(R.id.editText);
            switch (i) {
                case 0:
                    editText.setInputType(InputType.TYPE_CLASS_TEXT);
                    break;
                case 1:
                    editText.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
                    editText.setTypeface(Typeface.SANS_SERIF);
                    break;
            }
            mContentViews.add(i, view);
            mEditTextCountArr.set(i, 0);
            signInLinearLayout.addView(view);
        }

        ViewGroup footer = (ViewGroup) inflater.inflate(R.layout.footer_sign_in, signInLinearLayout,
                false);
        signInLinearLayout.addView(footer);
        mTcCheckbox = (CheckBox)findViewById(R.id.tcCheckBox);
        mTcCheckbox.setClickable(true);
        mTcCheckbox.setMovementMethod(LinkMovementMethod.getInstance());
        mTcCheckbox.setText(Html.fromHtml(getResources().getString(R.string.signIn_tc_Label) +" "+
                "<a href='"+getResources().getString(R.string.menu_tc_link)+"'>"+getResources().getString(R.string.signIn_tc_Clickable_Label)+"</a>"));

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);


    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        mMenu = menu;
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_signup, menu);
        return true;
    }

    @Override
    public boolean onPrepareOptionsMenu(Menu menu) {
        menu.findItem(R.id.ok).setVisible(false);
        return super.onPrepareOptionsMenu(menu);
    }

    private void checkRegisterButtonVisibility(){
        if (mMenu!=null){
            if (mEditTextCountArr.contains(0)){
                mMenu.findItem(R.id.ok).setVisible(false);
            }else{
                mMenu.findItem(R.id.ok).setVisible(true);
            }
        }
    }

    // CDEditText Callbacks

    @Override
    public void onTextCleared(CDEditText cdEditText) {
        mEditTextCountArr.set(cdEditText.getIndex(), 0);
        checkRegisterButtonVisibility();
    }

    @Override
    public void beforeTextChanged(CDEditText cdEditText, CharSequence charSequence, int i, int i1, int i2) {

    }

    @Override
    public void onTextChanged(CDEditText cdEditText, CharSequence charSequence, int i, int i1, int i2) {

    }

    @Override
    public void afterTextChanged(CDEditText cdEditText, Editable editable) {
        mEditTextCountArr.set(cdEditText.getIndex(), editable.length());
        checkRegisterButtonVisibility();
    }

    @Override
    public void onFocusChange(CDEditText cdEditText, View view, boolean b) {

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()){
            case android.R.id.home:
                this.finish();
                return true;
            case R.id.ok:
                if (checkTC()) {
                    HashMap<String, String> map = new HashMap<>();
                    map.put("username", getEditTextValue(0));
                    map.put("password", getEditTextValue(1));
                    performLogin(map, ApiType.APITYPE_SIGN_IN);
                }


        }

        return super.onOptionsItemSelected(item);
    }


    @Override
    public void onNetworkRequestSuccess(Call call, Response response, int apiType, int tagValue, String tagString) {
        super.onNetworkRequestSuccess(call, response, apiType, tagValue, tagString);
        switch (apiType){
            case ApiType.APITYPE_SIGN_IN:

                SigninResponse signInResponse = (SigninResponse)response.body();
                if (signInResponse.getStatus() == 0){
//                    String agentImageUrl = signInResponse.getResponse().getAgentInfo().getAgentPhoto();
//                    if (agentImageUrl!=null){
//                        Util.putStringToSharedPreferences(Keys.KEY_AGENTIMAGEURL, agentImageUrl, this);
//                        Util.downloadAgentImage(this);
//                    }
//                    Util.putObjectToSharedPreferences(Keys.KEY_AGENTINFO, signInResponse.getResponse().getAgentInfo(), this);
//                    Util.putIntegerToSharedPreferences(Keys.KEY_CREDITBALANCE, signInResponse.getResponse().getCreditBalance(), this);
                    Util.putStringToSharedPreferences(Keys.KEY_TOKEN, signInResponse.getResponse().getToken(), this);
                    Util.putStringToSharedPreferences(Keys.KEY_REFRESHTOKEN, signInResponse.getResponse().getRefreshToken(), this);
//                    Util.putLongToSharedPreferences(Keys.KEY_USERID, signInResponse.getResponse().getUserid(), this);
//                    Util.putStringToSharedPreferences(Keys.KEY_FIRSTNAME, signInResponse.getResponse().getAgentInfo().getFirstName(), this);
//                    Util.putStringToSharedPreferences(Keys.KEY_LASTNAME, signInResponse.getResponse().getAgentInfo().getLastName(), this);
//                    Util.putStringToSharedPreferences(Keys.KEY_USERNAME, signInResponse.getResponse().getAgentInfo().getPersonid() , this);
//                    Util.putBooleanToSharedPreferences(Keys.KEY_ISLAUNCHEDEARLIER, true, this);
                    if (apiType == ApiType.APITYPE_SIGN_IN){
                        Util.putStringToSharedPreferences(Keys.KEY_USERNAME, getEditTextValue(0), this);
                        Util.putStringToSharedPreferences(Keys.KEY_PASSWORD, getEditTextValue(1), this);
                    }

//                    Crashlytics.setUserIdentifier(signInResponse.getResponse().getUserid()+"");
//                    Crashlytics.setUserEmail(signInResponse.getResponse().getAgentInfo().getEmail());
//                    Crashlytics.setUserName(signInResponse.getResponse().getAgentInfo().getFirstName()+" "+signInResponse.getResponse().getAgentInfo().getLastName());
                    showMessage(R.string.signIn_userSignInSuccessMessage);
                    Intent i = new Intent(this, HomeActivity.class);
                    finish();
                    startActivity(i);
                }
                break;

        }
    }

    @Override
    public void onNetworkRequestFailure(Call call, Throwable t, int apiType, int tagValue, String tagString) {
        super.onNetworkRequestFailure(call, t, apiType, tagValue, tagString);
    }

    @Override
    protected void showAnimations(int apiType, int tagValue, String tagString) {
        Log.d("show animations ", apiType+"");
        switch (apiType){
            case ApiType.APITYPE_SIGN_IN:
            case ApiType.APITYPE_FACEBOOK_SIGN_IN:
            case ApiType.APITYPE_TWITTER_SIGN_IN:
            case ApiType.APITYPE_LINKED_IN_SIGN_IN:
            case ApiType.APITYPE_LINKED_IN_ACCESS:
            case ApiType.APITYPE_LINKED_IN_PROFILE:
                super.showAnimations(apiType, tagValue, tagString);
                break;
        }
    }

    @Override
    protected void hideAnimations(int apiType, int tagValue, String tagString) {
        Log.d("hide animations ", apiType+"");
        switch (apiType){
            case ApiType.APITYPE_SIGN_IN:
            case ApiType.APITYPE_FACEBOOK_SIGN_IN:
            case ApiType.APITYPE_TWITTER_SIGN_IN:
            case ApiType.APITYPE_LINKED_IN_SIGN_IN:
            case ApiType.APITYPE_LINKED_IN_ACCESS:
            case ApiType.APITYPE_LINKED_IN_PROFILE:
                super.hideAnimations(apiType, tagValue, tagString);
                break;
        }
    }

    public String getEditTextValue(int index){
        CDEditText rowView = (CDEditText) mContentViews.get(index).findViewById(R.id.cdEditText_cell);
        return rowView.getText();
    }


    public void forgotPasswordButtonTapped(View v){

    }

    private boolean checkTC(){
        if (!mTcCheckbox.isChecked()){
            showMessage(R.string.signIn_tc_validation_message);
            return false;
        }
        return true;
    }
}
