package com.chalkdigital.showcase.android.model.response;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * Created by arungupta on 22/06/16.
 */
public class BaseResponse implements Parcelable{
    private int ecode;
    private String edesc;
    private int status;


    public static final Creator<BaseResponse> CREATOR = new Creator<BaseResponse>() {
        @Override
        public BaseResponse createFromParcel(Parcel in) {
            return new BaseResponse(in);
        }

        @Override
        public BaseResponse[] newArray(int size) {
            return new BaseResponse[size];
        }
    };

    public int getEcode() {
        return ecode;
    }

    public void setEcode(int ecode) {
        this.ecode = ecode;
    }

    public String getEdesc() {
        return edesc;
    }

    public void setEdesc(String edesc) {
        this.edesc = edesc;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }


    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeInt(this.ecode);
        dest.writeString(this.edesc);
        dest.writeInt(this.status);
    }

    public BaseResponse() {
    }

    protected BaseResponse(Parcel in) {
        this.ecode = in.readInt();
        this.edesc = in.readString();
        this.status = in.readInt();
    }

}
