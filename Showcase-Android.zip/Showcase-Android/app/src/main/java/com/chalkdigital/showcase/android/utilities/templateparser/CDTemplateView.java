package com.chalkdigital.showcase.android.utilities.templateparser;

import android.content.Context;
import androidx.percentlayout.widget.PercentRelativeLayout;
import android.util.AttributeSet;

import com.chalkdigital.showcase.android.model.data.DesignData;

/**
 * Created by arungupta on 05/10/16.
 */

public class CDTemplateView extends PercentRelativeLayout {
    public DesignData properties;
    public CDTemplateView(Context context) {
        super(context);
    }
    public CDTemplateView(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public CDTemplateView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }
}
