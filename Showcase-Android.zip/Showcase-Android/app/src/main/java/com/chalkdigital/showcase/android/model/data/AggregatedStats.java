package com.chalkdigital.showcase.android.model.data;

import android.os.Parcel;
import android.os.Parcelable;

import java.util.List;

/**
 * Created by arungupta on 15/09/16.
 */
public class AggregatedStats implements Parcelable {
    private List<Stats> byGender;
    private List<Stats> byLocation;
    private List<Stats> byAge;
    private List<Stats> byDay;
    private List<Stats> byDevice;

    public List<Stats> getByGender() {
        return byGender;
    }

    public void setByGender(List<Stats> byGender) {
        this.byGender = byGender;
    }

    public List<Stats> getByLocation() {
        return byLocation;
    }

    public void setByLocation(List<Stats> byLocation) {
        this.byLocation = byLocation;
    }

    public List<Stats> getByAge() {
        return byAge;
    }

    public void setByAge(List<Stats> byAge) {
        this.byAge = byAge;
    }

    public List<Stats> getByDay() {
        return byDay;
    }

    public void setByDay(List<Stats> byDay) {
        this.byDay = byDay;
    }

    public List<Stats> getByDevice() {
        return byDevice;
    }

    public void setByDevice(List<Stats> byDevice) {
        this.byDevice = byDevice;
    }


    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeTypedList(this.byGender);
        dest.writeTypedList(this.byLocation);
        dest.writeTypedList(this.byAge);
        dest.writeTypedList(this.byDay);
        dest.writeTypedList(this.byDevice);
    }

    public AggregatedStats() {
    }

    protected AggregatedStats(Parcel in) {
        this.byGender = in.createTypedArrayList(Stats.CREATOR);
        this.byLocation = in.createTypedArrayList(Stats.CREATOR);
        this.byAge = in.createTypedArrayList(Stats.CREATOR);
        this.byDay = in.createTypedArrayList(Stats.CREATOR);
        this.byDevice = in.createTypedArrayList(Stats.CREATOR);
    }

    public static final Parcelable.Creator<AggregatedStats> CREATOR = new Parcelable.Creator<AggregatedStats>() {
        @Override
        public AggregatedStats createFromParcel(Parcel source) {
            return new AggregatedStats(source);
        }

        @Override
        public AggregatedStats[] newArray(int size) {
            return new AggregatedStats[size];
        }
    };
}
