package com.chalkdigital.showcase.android.contants;

/**
 * Created by arungupta on 08/07/16.
 */

public class RequestCodes {
    public static final int REQUEST_CODE_LINKEDIN_SIGNIN = 100;
    public static final int REQUEST_ACCESS_COARSE_LOCATION = 1;

}
