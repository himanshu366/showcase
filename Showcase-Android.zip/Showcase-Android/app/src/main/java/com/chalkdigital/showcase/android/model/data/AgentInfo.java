package com.chalkdigital.showcase.android.model.data;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * Created by arungupta on 22/06/16.
 */
public class AgentInfo implements Parcelable {
    private String address;
    private String agentPhoto;
    private String breNumber;
    private String cell;
    private String city;
    private String directOfficePhone;
    private String email;
    private String employeeTitle;
    private String fax;
    private String firstName;
    private String lastName;
    private String officeName;
    private String personid;
    private String preferredNumber;
    private String state;
    private String zip;

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getAgentPhoto() {
        return agentPhoto;
    }

    public void setAgentPhoto(String agentPhoto) {
        this.agentPhoto = agentPhoto;
    }

    public String getBreNumber() {
        return breNumber;
    }

    public void setBreNumber(String breNumber) {
        this.breNumber = breNumber;
    }

    public String getCell() {
        return cell;
    }

    public void setCell(String cell) {
        this.cell = cell;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getDirectOfficePhone() {
        return directOfficePhone;
    }

    public void setDirectOfficePhone(String directOfficePhone) {
        this.directOfficePhone = directOfficePhone;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getEmployeeTitle() {
        return employeeTitle;
    }

    public void setEmployeeTitle(String employeeTitle) {
        this.employeeTitle = employeeTitle;
    }

    public String getFax() {
        return fax;
    }

    public void setFax(String fax) {
        this.fax = fax;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getOfficeName() {
        return officeName;
    }

    public void setOfficeName(String officeName) {
        this.officeName = officeName;
    }

    public String getPersonid() {
        return personid;
    }

    public void setPersonid(String personid) {
        this.personid = personid;
    }

    public String getPreferredNumber() {
        return preferredNumber;
    }

    public void setPreferredNumber(String preferredNumber) {
        this.preferredNumber = preferredNumber;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getZip() {
        return zip;
    }

    public void setZip(String zip) {
        this.zip = zip;
    }


    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(this.address);
        dest.writeString(this.agentPhoto);
        dest.writeString(this.breNumber);
        dest.writeString(this.cell);
        dest.writeString(this.city);
        dest.writeString(this.directOfficePhone);
        dest.writeString(this.email);
        dest.writeString(this.employeeTitle);
        dest.writeString(this.fax);
        dest.writeString(this.firstName);
        dest.writeString(this.lastName);
        dest.writeString(this.officeName);
        dest.writeString(this.personid);
        dest.writeString(this.preferredNumber);
        dest.writeString(this.state);
        dest.writeString(this.zip);
    }

    public AgentInfo() {
    }

    protected AgentInfo(Parcel in) {
        this.address = in.readString();
        this.agentPhoto = in.readString();
        this.breNumber = in.readString();
        this.cell = in.readString();
        this.city = in.readString();
        this.directOfficePhone = in.readString();
        this.email = in.readString();
        this.employeeTitle = in.readString();
        this.fax = in.readString();
        this.firstName = in.readString();
        this.lastName = in.readString();
        this.officeName = in.readString();
        this.personid = in.readString();
        this.preferredNumber = in.readString();
        this.state = in.readString();
        this.zip = in.readString();
    }

    public static final Parcelable.Creator<AgentInfo> CREATOR = new Parcelable.Creator<AgentInfo>() {
        @Override
        public AgentInfo createFromParcel(Parcel source) {
            return new AgentInfo(source);
        }

        @Override
        public AgentInfo[] newArray(int size) {
            return new AgentInfo[size];
        }
    };
}
