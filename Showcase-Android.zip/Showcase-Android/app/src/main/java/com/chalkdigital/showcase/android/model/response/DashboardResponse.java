package com.chalkdigital.showcase.android.model.response;

import android.os.Parcel;

import com.chalkdigital.showcase.android.model.data.DashboardData;
import com.chalkdigital.showcase.android.model.data.Stats;

import java.util.List;

/**
 * Created by arungupta on 13/09/16.
 */
public class DashboardResponse extends BaseResponse{
    private DashboardData response;

    public DashboardData getResponse() {
        return response;
    }

    public void setResponse(DashboardData response) {
        this.response = response;
    }


    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        super.writeToParcel(dest, flags);
        dest.writeParcelable(this.response, flags);
    }

    public DashboardResponse() {
    }

    protected DashboardResponse(Parcel in) {
        super(in);
        this.response = in.readParcelable(DashboardData.class.getClassLoader());
    }

    public static final Creator<DashboardResponse> CREATOR = new Creator<DashboardResponse>() {
        @Override
        public DashboardResponse createFromParcel(Parcel source) {
            return new DashboardResponse(source);
        }

        @Override
        public DashboardResponse[] newArray(int size) {
            return new DashboardResponse[size];
        }
    };
}