package com.chalkdigital.showcase.android.model.data;

public class WebSocketResponseData {
    private int error_code;
    private int status;
    private RealTimeImpressionResponse response;

    public int getError_code() {
        return error_code;
    }

    public void setError_code(int error_code) {
        this.error_code = error_code;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public RealTimeImpressionResponse getResponse() {
        return response;
    }

    public void setResponse(RealTimeImpressionResponse response) {
        this.response = response;
    }
}
