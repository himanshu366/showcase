package com.chalkdigital.showcase.android.listeners;

/**
 * Created by arungupta on 22/09/16.
 */
public interface DrawerClickListener{
    public void onDrawerItemClick(int index);
}

