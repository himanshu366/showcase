package com.chalkdigital.showcase.android.model.data;

import android.os.Parcel;
import android.os.Parcelable;

import java.util.HashMap;

/**
 * Created by arungupta on 14/10/16.
 */

public class DesignData implements Parcelable, Cloneable{
    private String type;
    private String id;
    private String backroundColor;
    private String alpha;
    private String height;
    private String width;
    private String dataTag;
    private String addImageEnabled;
    private String placeholder;
    private String marginTop;
    private String center;
    private String fontName;
    private String fontSize;
    private String fontLineSpacing;
    private String fontCharSpacing;
    private String textColor;
    private String alignment;
    private String style;
    private String scale;
    private String marginLeft;
    private String toRightOf;
    private String below;
    public String getBelow() {
        return below;
    }
    public void setBelow(String below) {
        this.below = below;
    }



    private HashMap<String, DesignData> containers;



    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getBackgroundColor() {
        return backroundColor;
    }

    public void setBackgroundColor(String backgroundColor) {
        this.backroundColor = backgroundColor;
    }

    public String getAlpha() {
        return alpha;
    }

    public void setAlpha(String alpha) {
        this.alpha = alpha;
    }

    public String getHeight() {
        return height;
    }

    public void setHeight(String height) {
        this.height = height;
    }

    public String getWidth() {
        return width;
    }

    public void setWidth(String width) {
        this.width = width;
    }

    public String getDataTag() {
        return dataTag;
    }

    public void setDataTag(String dataTag) {
        this.dataTag = dataTag;
    }

    public boolean getAddImageEnabled() {
        if (addImageEnabled!=null && addImageEnabled.equals("true"))
            return true;
        else return false;
    }

    public void setAddImageEnabled(String addImageEnabled) {
        this.addImageEnabled = addImageEnabled;
    }

    public String getPlaceholder() {
        return placeholder;
    }

    public void setPlaceholder(String placeholder) {
        this.placeholder = placeholder;
    }

    public String getMarginTop() {
        return marginTop;
    }

    public void setMarginTop(String marginTop) {
        this.marginTop = marginTop;
    }

    public String getCenter() {
        return center;
    }

    public void setCenter(String center) {
        this.center = center;
    }

    public String getFontName() {
        return fontName;
    }

    public void setFontName(String fontName) {
        this.fontName = fontName;
    }

    public String getFontSize() {
        return fontSize;
    }

    public void setFontSize(String fontSize) {
        this.fontSize = fontSize;
    }

    public String getFontLineSpacing() {
        return fontLineSpacing;
    }

    public void setFontLineSpacing(String fontLineSpacing) {
        this.fontLineSpacing = fontLineSpacing;
    }

    public String getFontCharSpacing() {
        return fontCharSpacing;
    }

    public void setFontCharSpacing(String fontCharSpacing) {
        this.fontCharSpacing = fontCharSpacing;
    }

    public String getTextColor() {
        return textColor;
    }

    public void setTextColor(String textColor) {
        this.textColor = textColor;
    }

    public String getAlignMent() {
        return alignment;
    }

    public void setAlignMent(String alignMent) {
        this.alignment = alignMent;
    }

    public String getStyle() {
        return style;
    }

    public void setStyle(String style) {
        this.style = style;
    }

    public String getScale() {
        return scale;
    }

    public void setScale(String scale) {
        this.scale = scale;
    }

    public String getMarginLeft() {
        return marginLeft;
    }

    public void setMarginLeft(String marginLeft) {
        this.marginLeft = marginLeft;
    }

    public String getToRightOf() {
        return toRightOf;
    }

    public void setToRightOf(String toRightOf) {
        this.toRightOf = toRightOf;
    }

    public HashMap<String, DesignData> getContainers() {
        return containers;
    }

    public void setContainers(HashMap<String, DesignData> containers) {
        this.containers = containers;
    }


    public DesignData() {
    }

    @Override
    public Object clone(){
        try {
            return super.clone();
        } catch (CloneNotSupportedException e) {
            e.printStackTrace();
            return null;
        }
    }


    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(this.type);
        dest.writeString(this.id);
        dest.writeString(this.backroundColor);
        dest.writeString(this.alpha);
        dest.writeString(this.height);
        dest.writeString(this.width);
        dest.writeString(this.dataTag);
        dest.writeString(this.addImageEnabled);
        dest.writeString(this.placeholder);
        dest.writeString(this.marginTop);
        dest.writeString(this.center);
        dest.writeString(this.fontName);
        dest.writeString(this.fontSize);
        dest.writeString(this.fontLineSpacing);
        dest.writeString(this.fontCharSpacing);
        dest.writeString(this.textColor);
        dest.writeString(this.alignment);
        dest.writeString(this.style);
        dest.writeString(this.scale);
        dest.writeString(this.marginLeft);
        dest.writeString(this.toRightOf);
        dest.writeString(this.below);
        dest.writeSerializable(this.containers);
    }

    protected DesignData(Parcel in) {
        this.type = in.readString();
        this.id = in.readString();
        this.backroundColor = in.readString();
        this.alpha = in.readString();
        this.height = in.readString();
        this.width = in.readString();
        this.dataTag = in.readString();
        this.addImageEnabled = in.readString();
        this.placeholder = in.readString();
        this.marginTop = in.readString();
        this.center = in.readString();
        this.fontName = in.readString();
        this.fontSize = in.readString();
        this.fontLineSpacing = in.readString();
        this.fontCharSpacing = in.readString();
        this.textColor = in.readString();
        this.alignment = in.readString();
        this.style = in.readString();
        this.scale = in.readString();
        this.marginLeft = in.readString();
        this.toRightOf = in.readString();
        this.below = in.readString();
        this.containers = (HashMap<String, DesignData>) in.readSerializable();
    }

    public static final Creator<DesignData> CREATOR = new Creator<DesignData>() {
        @Override
        public DesignData createFromParcel(Parcel source) {
            return new DesignData(source);
        }

        @Override
        public DesignData[] newArray(int size) {
            return new DesignData[size];
        }
    };
}
