package com.chalkdigital.showcase.android.model;

/**
 * Created by arungupta on 21/06/16.
 */
public class Book {
    //Variables that are in our json
    private int bookId;
    private String name;
    private String price;
    private int inStock;

    //Getters and setters
    public int getBookId() {
        return bookId;
    }

    public void setBookId(int bookId) {
        this.bookId = bookId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public int getInStock() {
        return inStock;
    }

    public void setInStock(int inStock) {
        this.inStock = inStock;
    }
}
