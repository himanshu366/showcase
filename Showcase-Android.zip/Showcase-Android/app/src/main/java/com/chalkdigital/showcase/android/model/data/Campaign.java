package com.chalkdigital.showcase.android.model.data;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * Created by arungupta on 13/09/16.
 */
public class Campaign implements Parcelable {
    private String name;
    private String startDate;
    private String endDate;
    private AggregatedStats stats;

    public AggregatedStats getStats() {
        return stats;
    }

    public void setStats(AggregatedStats stats) {
        this.stats = stats;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getStartDate() {
        return startDate;
    }

    public void setStartDate(String startDate) {
        this.startDate = startDate;
    }

    public String getEndDate() {
        return endDate;
    }

    public void setEndDate(String endDate) {
        this.endDate = endDate;
    }


    public Campaign() {
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(this.name);
        dest.writeString(this.startDate);
        dest.writeString(this.endDate);
        dest.writeParcelable(this.stats, flags);
    }

    protected Campaign(Parcel in) {
        this.name = in.readString();
        this.startDate = in.readString();
        this.endDate = in.readString();
        this.stats = in.readParcelable(AggregatedStats.class.getClassLoader());
    }

    public static final Creator<Campaign> CREATOR = new Creator<Campaign>() {
        @Override
        public Campaign createFromParcel(Parcel source) {
            return new Campaign(source);
        }

        @Override
        public Campaign[] newArray(int size) {
            return new Campaign[size];
        }
    };
}
