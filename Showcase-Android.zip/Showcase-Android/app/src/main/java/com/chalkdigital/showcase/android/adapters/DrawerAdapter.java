package com.chalkdigital.showcase.android.adapters;

import android.content.Context;
import android.database.DataSetObserver;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListAdapter;
import android.widget.TextView;

import com.chalkdigital.showcase.android.R;
import com.chalkdigital.showcase.android.listeners.DrawerClickListener;

/**
 * Created by arungupta on 22/09/16.
 */
public class DrawerAdapter implements ListAdapter, AdapterView.OnItemClickListener {

    private Context mContext;
    private DrawerClickListener mDrawerClickListener;

    public DrawerAdapter(Context context, final DrawerClickListener drawerClickListener) {
        mContext = context;
        mDrawerClickListener = drawerClickListener;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        if (view == null){
            LayoutInflater inflater = (LayoutInflater)mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            view = inflater.inflate(R.layout.drawer_list_cell, viewGroup, false);
        }
        TextView textView = (TextView)view.findViewById(R.id.drawer_cell_button);
        textView.setCompoundDrawablesWithIntrinsicBounds(mContext.getResources().getDrawable(mContext.getResources().getIdentifier("drawerIcon_"+i, "drawable", mContext.getPackageName())), null, mContext.getResources().getDrawable(R.drawable.arrow), null);
        textView.setText(mContext.getString(mContext.getResources().getIdentifier("drawerLabel_"+i, "string", mContext.getPackageName())));
        return view;
    }

    @Override
    public boolean hasStableIds() {
        return true;
    }

    @Override
    public int getItemViewType(int i) {
        return R.layout.drawer_list_cell;
    }

    @Override
    public void registerDataSetObserver(DataSetObserver dataSetObserver) {

    }

    @Override
    public int getViewTypeCount() {
        return 1;
    }

    @Override
    public boolean isEmpty() {
        return false;
    }

    @Override
    public void unregisterDataSetObserver(DataSetObserver dataSetObserver) {

    }

    @Override
    public int getCount() {
        return 4;
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public boolean areAllItemsEnabled() {
        return true;
    }

    @Override
    public Object getItem(int i) {
        return null;
    }

    @Override
    public boolean isEnabled(int i) {
        return true;
    }

    @Override
    public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
        if (mDrawerClickListener!=null){
            mDrawerClickListener.onDrawerItemClick(i-1);
        }
    }
}
