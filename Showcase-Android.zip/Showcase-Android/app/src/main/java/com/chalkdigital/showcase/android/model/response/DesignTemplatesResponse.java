package com.chalkdigital.showcase.android.model.response;

import android.os.Parcel;

import com.chalkdigital.showcase.android.model.data.DesignTemplate;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by arungupta on 13/10/16.
 */

public class DesignTemplatesResponse extends BaseResponse implements Serializable {

    private Map<String , ArrayList<DesignTemplate>> response;

    public Map<String, ArrayList<DesignTemplate>> getResponse() {
        return response;
    }

    public void setResponse(Map<String, ArrayList<DesignTemplate>> response) {
        this.response = response;
    }


    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        super.writeToParcel(dest, flags);
        dest.writeInt(this.response.size());
        for (Map.Entry<String, ArrayList<DesignTemplate>> entry : this.response.entrySet()) {
            dest.writeString(entry.getKey());
            dest.writeTypedList(entry.getValue());
        }
    }

    public DesignTemplatesResponse() {
    }

    protected DesignTemplatesResponse(Parcel in) {
        super(in);
        int responseSize = in.readInt();
        this.response = new HashMap<String, ArrayList<DesignTemplate>>(responseSize);
        for (int i = 0; i < responseSize; i++) {
            String key = in.readString();
            ArrayList<DesignTemplate> value = in.createTypedArrayList(DesignTemplate.CREATOR);
            this.response.put(key, value);
        }
    }

    public static final Creator<DesignTemplatesResponse> CREATOR = new Creator<DesignTemplatesResponse>() {
        @Override
        public DesignTemplatesResponse createFromParcel(Parcel source) {
            return new DesignTemplatesResponse(source);
        }

        @Override
        public DesignTemplatesResponse[] newArray(int size) {
            return new DesignTemplatesResponse[size];
        }
    };
}
