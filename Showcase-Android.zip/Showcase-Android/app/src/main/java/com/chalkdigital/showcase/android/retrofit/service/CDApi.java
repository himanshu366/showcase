package com.chalkdigital.showcase.android.retrofit.service;

import com.chalkdigital.showcase.android.model.Book;
import com.chalkdigital.showcase.android.model.response.AgentImageUploadRespose;
import com.chalkdigital.showcase.android.model.response.DashboardResponse;
import com.chalkdigital.showcase.android.model.response.DesignTemplatesResponse;
import com.chalkdigital.showcase.android.model.response.LinkedInAccessResponse;
import com.chalkdigital.showcase.android.model.response.LinkedInProfileResponse;
import com.chalkdigital.showcase.android.model.response.SigninResponse;
import com.chalkdigital.showcase.android.model.response.SignupResponse;

import java.util.HashMap;
import java.util.List;

import okhttp3.RequestBody;
import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.Headers;
import retrofit2.http.POST;
import retrofit2.http.Url;

/**
 * Created by arungupta on 20/06/16.
 */
public interface CDApi {

    @GET("/s/mrolbrglh0vjote/books.json")
    Call<List<Book>> getBooks();

    @POST("/bh/login/v1")
    Call<SigninResponse> signin(@Body HashMap<String , String> body);

    @POST("/bh/signup/v1")
    Call<SignupResponse> signup(@Body HashMap<String , String> body);

    @POST("/photo/v1?type=user&ttlInDays=0")
    Call<AgentImageUploadRespose> uploadAgentImage(@Body HashMap<String , String> body);

    @Headers({
            "Content-Type: application/x-www-form-urlencoded"
    })
    @POST("/uas/oauth2/accessToken")
    Call<LinkedInAccessResponse> linkedInAccess(@Body RequestBody body);

    @GET("/v1/people/~?format=json")
    Call<LinkedInProfileResponse> linkedInProfile();

    @GET
    Call<DashboardResponse> dashboard(@Url String requestUrl);

    @GET
    Call<ResponseBody> downloadFile(@Url String fileUrl);

    @GET("/template/byCategory/v1?category=Generic&size=300x250,300x50")
    Call<DesignTemplatesResponse> designTemplates();
}
