package com.chalkdigital.showcase.android.model.data;

import android.net.Uri;
import android.os.Parcel;
import android.os.Parcelable;
import android.view.View;

import java.util.HashSet;
import java.util.Set;

/**
 * Created by arungupta on 14/10/16.
 */

public class UserData implements Parcelable {
    private String image;
    private String text;
    private boolean textChanged;
    private boolean colorChanged;
    private Set<View> views;
    private Uri uri;

    public Uri getUri() {
        return uri;
    }

    public void setUri(Uri uri) {
        this.uri = uri;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    public boolean isColorChanged() {
        return colorChanged;
    }

    public void setColorChanged(boolean colorChanged) {
        this.colorChanged = colorChanged;
    }

    public boolean isTextChanged() {
        return textChanged;
    }

    public void setTextChanged(boolean textChanged) {
        this.textChanged = textChanged;
    }

    public Set<View> getViews() {
        if (views != null)
            return views;
        else return new HashSet<>();
    }

    public void setViews(Set<View> views) {
        this.views = views;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(this.image);
        dest.writeString(this.text);
        dest.writeInt(this.textChanged ? 1 : 0);
        dest.writeInt(this.colorChanged ? 1 : 0);
    }

    public UserData() {
    }

    protected UserData(Parcel in) {
        this.image = in.readString();
        this.text = in.readString();
        this.textChanged = in.readInt() != 0;
        this.colorChanged = in.readInt() != 0;
    }

    public static final Creator<UserData> CREATOR = new Creator<UserData>() {
        @Override
        public UserData createFromParcel(Parcel source) {
            return new UserData(source);
        }

        @Override
        public UserData[] newArray(int size) {
            return new UserData[size];
        }
    };
}
