package com.chalkdigital.showcase.android.model.response;

import android.os.Parcel;

/**
 * Created by arungupta on 08/07/16.
 */

public class AgentImageUploadRespose extends BaseResponse {
    private String response;

    public String getResponse() {
        return response;
    }

    public void setResponse(String response) {
        this.response = response;
    }


    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        super.writeToParcel(dest, flags);
        dest.writeString(this.response);
    }

    public AgentImageUploadRespose() {
    }

    protected AgentImageUploadRespose(Parcel in) {
        super(in);
        this.response = in.readString();
    }

    public static final Creator<AgentImageUploadRespose> CREATOR = new Creator<AgentImageUploadRespose>() {
        @Override
        public AgentImageUploadRespose createFromParcel(Parcel source) {
            return new AgentImageUploadRespose(source);
        }

        @Override
        public AgentImageUploadRespose[] newArray(int size) {
            return new AgentImageUploadRespose[size];
        }
    };
}
