package com.chalkdigital.showcase.android.contants;

import android.graphics.Color;

/**
 * Created by arungupta on 21/06/16.
 */
public class Constants {
    public static final int CONSTANT_READ_TIMEOUT_INTERVAL                   =  10;
    public static final int CONSTANT_CONNECTION_TIMEOUT_INTERVAL             =  5;
    public static final int CONSTANT_DesignImageViewTag                      =  50;

    public final static String EMAIL_REGEX                                   = "[a-zA-Z0-9\\+\\.\\_\\%\\-\\+]{1,2" +
            "56}"
            + "\\@"
            + "[a-zA-Z0-9][a-zA-Z0-9\\-]{0,64}"
            + "("
            + "\\."
            + "[a-zA-Z0-9][a-zA-Z0-9\\-]{0,25}" + ")+";


    public static final int tintColor = Color.rgb(32, 215, 222);
    public static final int[] CHART_COLORS = {
            Color.rgb(20, 54, 81), Color.rgb(81, 100, 115),tintColor,
            Color.rgb(32, 164, 243), Color.rgb(128, 57, 216), Color.rgb(10, 87, 147),
            Color.rgb(201, 200, 200), Color.rgb(79, 195, 160), Color.rgb(225, 32, 111),
    };

}
